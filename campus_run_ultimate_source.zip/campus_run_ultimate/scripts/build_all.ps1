# Campus Run Ultimate - Windows 11 自动化构建与验收脚本
# 用法: 在项目根目录以 PowerShell 执行 .\scripts\build_all.ps1

$ErrorActionPreference = "Stop"

Write-Host "=== [1/6] 检查 Flutter 开发环境 ===" -ForegroundColor Cyan
flutter doctor -v

Write-Host "`n=== [2/6] 拉取依赖 (flutter pub get) ===" -ForegroundColor Cyan
flutter pub get

Write-Host "`n=== [3/6] 静态代码分析 (flutter analyze) ===" -ForegroundColor Cyan
flutter analyze

Write-Host "`n=== [4/6] 运行自动化测试 (flutter test) ===" -ForegroundColor Cyan
flutter test --reporter expanded

Write-Host "`n=== [5/6] 构建 Android Release APK ===" -ForegroundColor Cyan
flutter build apk --release
Write-Host "APK 输出位置: build\app\outputs\flutter-apk\app-release.apk" -ForegroundColor Green

Write-Host "`n=== [6/6] 构建 Windows 11 Release 桌面包 ===" -ForegroundColor Cyan
flutter build windows --release
Write-Host "Windows 桌面包输出位置: build\windows\x64\runner\Release\" -ForegroundColor Green

Write-Host "`n全部构建与测试步骤完成！" -ForegroundColor Green
