package com.campusrun.ultimate

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
