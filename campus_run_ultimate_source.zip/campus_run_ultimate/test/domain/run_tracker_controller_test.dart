import 'dart:async';

import 'package:campus_run_ultimate/data/models/track_point.dart';
import 'package:campus_run_ultimate/data/services/location_service.dart';
import 'package:campus_run_ultimate/domain/tracking/run_tracker_controller.dart';
import 'package:flutter_test/flutter_test.dart';

class _FakeLocationService implements LocationService {
  final StreamController<TrackPoint> controller = StreamController<TrackPoint>.broadcast();

  @override
  Future<void> ensurePermissionAndService() async {}

  @override
  Stream<TrackPoint> watchPositionStream() => controller.stream;

  Future<void> close() => controller.close();
}

void main() {
  group('RunTrackerController 状态机测试', () {
    test('开始 -> 采集 -> 暂停 -> 恢复 -> 结束完整流程', () async {
      final fakeGps = _FakeLocationService();
      final tracker = RunTrackerController(locationService: fakeGps);

      expect(tracker.status, RunTrackingStatus.idle);
      await tracker.startRun();
      expect(tracker.status, RunTrackingStatus.acquiringGps);

      final t0 = DateTime.utc(2026, 11, 19, 8, 0, 0);
      fakeGps.controller.add(TrackPoint(latitude: 39.9900, longitude: 116.3000, accuracy: 5, timestamp: t0));
      await Future<void>.delayed(Duration.zero);
      expect(tracker.status, RunTrackingStatus.running);

      // 有效移动点（约 11m，耗时 3 秒）
      fakeGps.controller.add(TrackPoint(latitude: 39.9901, longitude: 116.3000, accuracy: 5, timestamp: t0.add(const Duration(seconds: 3))));
      await Future<void>.delayed(Duration.zero);
      expect(tracker.points.length, 2);
      expect(tracker.distanceMeters, greaterThan(10.0));

      // 暂停期间的新点应被忽略
      tracker.pauseRun();
      expect(tracker.status, RunTrackingStatus.paused);
      fakeGps.controller.add(TrackPoint(latitude: 39.9902, longitude: 116.3000, accuracy: 5, timestamp: t0.add(const Duration(seconds: 6))));
      await Future<void>.delayed(Duration.zero);
      expect(tracker.points.length, 2);

      // 恢复后继续采集
      tracker.resumeRun();
      expect(tracker.status, RunTrackingStatus.running);
      fakeGps.controller.add(TrackPoint(latitude: 39.9902, longitude: 116.3000, accuracy: 5, timestamp: t0.add(const Duration(seconds: 9))));
      await Future<void>.delayed(Duration.zero);
      expect(tracker.points.length, 3);

      final session = await tracker.stopAndBuildSession(customTitle: '自动化测试跑步');
      expect(session, isNotNull);
      expect(session!.title, '自动化测试跑步');
      expect(tracker.status, RunTrackingStatus.finished);

      tracker.dispose();
      await fakeGps.close();
    });

    test('GPS 异常事件触发 gpsLost，后续有效点到达后自动恢复 running', () async {
      final fakeGps = _FakeLocationService();
      final tracker = RunTrackerController(locationService: fakeGps);

      await tracker.startRun();
      final t0 = DateTime.utc(2026, 11, 19, 8, 0, 0);
      fakeGps.controller.add(TrackPoint(latitude: 39.9900, longitude: 116.3000, accuracy: 5, timestamp: t0));
      await Future<void>.delayed(Duration.zero);

      fakeGps.controller.addError('satellite lost');
      await Future<void>.delayed(Duration.zero);
      expect(tracker.status, RunTrackingStatus.gpsLost);

      fakeGps.controller.add(TrackPoint(latitude: 39.9901, longitude: 116.3000, accuracy: 5, timestamp: t0.add(const Duration(seconds: 5))));
      await Future<void>.delayed(Duration.zero);
      expect(tracker.status, RunTrackingStatus.running);

      tracker.dispose();
      await fakeGps.close();
    });
  });
}
