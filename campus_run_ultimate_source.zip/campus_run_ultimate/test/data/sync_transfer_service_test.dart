import 'package:campus_run_ultimate/core/errors/app_exception.dart';
import 'package:campus_run_ultimate/data/models/run_session.dart';
import 'package:campus_run_ultimate/data/models/track_point.dart';
import 'package:campus_run_ultimate/data/services/sync_transfer_service.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const service = SyncTransferService();

  group('SyncTransferService 离线同步包完整性测试', () {
    test('正常同步包导出并校验通过', () {
      final t0 = DateTime.utc(2026, 11, 19, 9, 0, 0);
      final session = RunSession(
        id: 'sync_1',
        title: '晚间 3 公里',
        startedAt: t0,
        endedAt: t0.add(const Duration(minutes: 15)),
        distanceMeters: 3000.0,
        movingDuration: const Duration(minutes: 15),
        elevationGainMeters: 12.0,
        sourceDevice: 'android',
        points: [
          TrackPoint(latitude: 39.99, longitude: 116.30, timestamp: t0),
          TrackPoint(latitude: 39.995, longitude: 116.30, timestamp: t0.add(const Duration(minutes: 15))),
        ],
      );

      final raw = service.createSyncBundle([session], exportedFrom: 'Android');
      final decoded = service.parseSyncBundle(raw);
      expect(decoded.length, 1);
      expect(decoded.first.id, 'sync_1');
      expect(decoded.first.points.length, 2);
    });

    test('被篡改的同步包触发 SyncIntegrityException', () {
      final t0 = DateTime.utc(2026, 11, 19, 9, 0, 0);
      final session = RunSession(
        id: 'sync_2',
        title: '原始标题',
        startedAt: t0,
        endedAt: t0.add(const Duration(minutes: 10)),
        distanceMeters: 2000.0,
        movingDuration: const Duration(minutes: 10),
        elevationGainMeters: 0.0,
        sourceDevice: 'android',
      );
      final raw = service.createSyncBundle([session], exportedFrom: 'Android');
      final tampered = raw.replaceFirst('原始标题', '被篡改标题');

      expect(
        () => service.parseSyncBundle(tampered),
        throwsA(isA<SyncIntegrityException>()),
      );
    });
  });
}
