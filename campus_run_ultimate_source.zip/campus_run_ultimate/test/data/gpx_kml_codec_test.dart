import 'package:campus_run_ultimate/core/errors/app_exception.dart';
import 'package:campus_run_ultimate/data/models/run_session.dart';
import 'package:campus_run_ultimate/data/models/track_point.dart';
import 'package:campus_run_ultimate/data/services/gpx_kml_codec.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const codec = GpxKmlCodec();

  RunSession sampleSession() {
    final t0 = DateTime.utc(2026, 11, 19, 7, 30, 0);
    return RunSession(
      id: 'run_test_001',
      title: '北操场晨跑',
      startedAt: t0,
      endedAt: t0.add(const Duration(seconds: 60)),
      distanceMeters: 250.0,
      movingDuration: const Duration(seconds: 60),
      elevationGainMeters: 3.0,
      sourceDevice: 'android',
      notes: '配速稳定',
      points: [
        TrackPoint(latitude: 39.9920, longitude: 116.3050, altitude: 45.0, timestamp: t0),
        TrackPoint(latitude: 39.9930, longitude: 116.3050, altitude: 48.0, timestamp: t0.add(const Duration(seconds: 30))),
        TrackPoint(latitude: 39.9940, longitude: 116.3050, altitude: 47.0, timestamp: t0.add(const Duration(seconds: 60))),
      ],
    );
  }

  group('GpxKmlCodec 导入导出测试', () {
    test('GPX 1.1 编码与解码往返一致', () {
      final session = sampleSession();
      final xml = codec.encodeGpx(session);
      final parsed = codec.decodeGpx(xml, fallbackId: 'gpx_roundtrip');

      expect(parsed.title, '北操场晨跑');
      expect(parsed.points.length, 3);
      expect(parsed.points.first.latitude, closeTo(39.9920, 1e-6));
      expect(parsed.distanceMeters, greaterThan(200.0));
    });

    test('KML 2.2 编码与解码往返一致', () {
      final session = sampleSession();
      final xml = codec.encodeKml(session);
      final parsed = codec.decodeKml(xml, fallbackId: 'kml_roundtrip');

      expect(parsed.title, '北操场晨跑');
      expect(parsed.points.length, 3);
      expect(parsed.points.last.longitude, closeTo(116.3050, 1e-6));
    });

    test('非法 XML 抛出 FileFormatException', () {
      expect(
        () => codec.decodeGpx('<gpx><broken></gpx>', fallbackId: 'bad'),
        throwsA(isA<FileFormatException>()),
      );
      expect(
        () => codec.decodeKml('<kml></kml>', fallbackId: 'bad_kml'),
        throwsA(isA<FileFormatException>()),
      );
    });
  });
}
