import 'package:campus_run_ultimate/app.dart';
import 'package:campus_run_ultimate/data/models/campus_route.dart';
import 'package:campus_run_ultimate/data/models/run_session.dart';
import 'package:campus_run_ultimate/data/repositories/run_repository.dart';
import 'package:flutter_test/flutter_test.dart';

class _InMemoryRunRepository extends RunRepository {
  final List<RunSession> _sessions = [];
  final List<CampusRoute> _routes = [];

  @override
  Future<List<RunSession>> fetchSessions({bool includePoints = false}) async =>
      List.unmodifiable(_sessions);

  @override
  Future<void> saveSession(RunSession session) async {
    _sessions.removeWhere((s) => s.id == session.id);
    _sessions.add(session);
  }

  @override
  Future<void> deleteSession(String id) async {
    _sessions.removeWhere((s) => s.id == id);
  }

  @override
  Future<List<CampusRoute>> fetchRoutes() async => List.unmodifiable(_routes);

  @override
  Future<void> saveRoute(CampusRoute route) async {
    _routes.removeWhere((r) => r.id == route.id);
    _routes.add(route);
  }
}

void main() {
  testWidgets('Android 移动端主界面冒烟测试（中文 Material 3 导航）', (tester) async {
    await tester.pumpWidget(
      CampusRunApp(
        repository: _InMemoryRunRepository(),
        forceDesktopMode: false,
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('实时校园跑'), findsOneWidget);
    expect(find.text('开始真实 GPS 跑步记录'), findsOneWidget);
    expect(find.text('历史记录'), findsOneWidget);
  });

  testWidgets('Windows 11 桌面端主界面冒烟测试（侧边栏导航与仪表盘）', (tester) async {
    await tester.pumpWidget(
      CampusRunApp(
        repository: _InMemoryRunRepository(),
        forceDesktopMode: true,
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('运动数据仪表盘'), findsOneWidget);
    expect(find.text('路线编辑器'), findsOneWidget);
    expect(find.text('轨迹回放分析'), findsOneWidget);
    expect(find.text('同步与导入导出'), findsOneWidget);
  });
}
