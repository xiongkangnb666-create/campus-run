import 'package:campus_run_ultimate/core/utils/geo_math.dart';
import 'package:campus_run_ultimate/data/models/track_point.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('GeoMath 轨迹数学与滤波算法测试', () {
    test('Haversine 距离计算精度校验（约 111.19 km / 1度纬度）', () {
      final d = GeoMath.haversineDistanceMeters(39.0, 116.0, 40.0, 116.0);
      expect(d, closeTo(111195.0, 200.0));
    });

    test('累计爬升过滤小于 1.5m 的气压/海拔微小抖动', () {
      final t0 = DateTime.utc(2026, 11, 19, 8, 0, 0);
      final pts = [
        TrackPoint(latitude: 39.99, longitude: 116.30, altitude: 50.0, timestamp: t0),
        TrackPoint(latitude: 39.99, longitude: 116.30, altitude: 50.8, timestamp: t0.add(const Duration(seconds: 5))),
        TrackPoint(latitude: 39.99, longitude: 116.30, altitude: 55.0, timestamp: t0.add(const Duration(seconds: 10))),
        TrackPoint(latitude: 39.99, longitude: 116.30, altitude: 53.0, timestamp: t0.add(const Duration(seconds: 15))),
        TrackPoint(latitude: 39.99, longitude: 116.30, altitude: 57.5, timestamp: t0.add(const Duration(seconds: 20))),
      ];
      expect(GeoMath.elevationGainMeters(pts), closeTo(9.5, 0.01));
    });

    test('配速计算（5公里用时25分钟应为 300秒/公里）', () {
      final pace = GeoMath.paceSecondsPerKm(5000.0, const Duration(minutes: 25));
      expect(pace, closeTo(300.0, 0.01));
    });

    test('异常漂移点拦截（超速尖刺与精度过差）', () {
      final t0 = DateTime.utc(2026, 11, 19, 8, 0, 0);
      final p0 = TrackPoint(latitude: 39.9900, longitude: 116.3000, accuracy: 6.0, timestamp: t0);
      // 1 秒瞬移 ~111 米，超速
      final spike = TrackPoint(latitude: 39.9910, longitude: 116.3000, accuracy: 8.0, timestamp: t0.add(const Duration(seconds: 1)));
      // 精度 80m 超出 35m 阈值
      final noisy = TrackPoint(latitude: 39.99002, longitude: 116.3000, accuracy: 80.0, timestamp: t0.add(const Duration(seconds: 2)));
      // 正常跑步：2 秒移动约 5.5 米
      final normal = TrackPoint(latitude: 39.99005, longitude: 116.3000, accuracy: 5.0, timestamp: t0.add(const Duration(seconds: 2)));

      expect(GeoMath.isOutlierPoint(previous: p0, candidate: spike), isTrue);
      expect(GeoMath.isOutlierPoint(previous: p0, candidate: noisy), isTrue);
      expect(GeoMath.isOutlierPoint(previous: p0, candidate: normal), isFalse);
    });

    test('Douglas-Peucker 直线轨迹抽稀保留首尾节点', () {
      final t0 = DateTime.utc(2026, 11, 19, 8, 0, 0);
      final line = List.generate(
        10,
        (i) => TrackPoint(
          latitude: 39.99 + i * 0.0001,
          longitude: 116.30,
          timestamp: t0.add(Duration(seconds: i * 3)),
        ),
      );
      final simplified = GeoMath.simplifyTrack(line, toleranceMeters: 2.0);
      expect(simplified.length, 2);
      expect(simplified.first.latitude, closeTo(39.99, 1e-6));
      expect(simplified.last.latitude, closeTo(39.9909, 1e-6));
    });
  });
}
