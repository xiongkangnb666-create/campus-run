import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';

import '../../core/constants/app_constants.dart';
import '../../core/utils/geo_math.dart';
import '../../data/models/run_session.dart';
import '../../data/models/track_point.dart';
import '../../data/services/location_service.dart';

/// 跑步采集状态机枚举
enum RunTrackingStatus {
  idle,
  acquiringGps,
  running,
  paused,
  gpsLost,
  finished,
}

/// 真实 GPS 跑步采集状态机控制器
/// 支持：定位等待、正常记录、暂停/恢复、GPS 丢失告警与自动恢复、异常漂移点过滤
class RunTrackerController extends ChangeNotifier {
  RunTrackerController({
    required LocationService locationService,
    Duration? gpsTimeout,
  })  : _locationService = locationService,
        _gpsTimeout = gpsTimeout ?? AppConstants.gpsSignalTimeout;

  final LocationService _locationService;
  final Duration _gpsTimeout;

  RunTrackingStatus _status = RunTrackingStatus.idle;
  final List<TrackPoint> _points = [];
  DateTime? _startedAt;
  DateTime? _lastPointAt;
  Duration _movingDuration = Duration.zero;
  double _distanceMeters = 0.0;
  String? _errorMessage;
  int _filteredOutlierCount = 0;

  StreamSubscription<TrackPoint>? _gpsSub;
  Timer? _ticker;

  RunTrackingStatus get status => _status;
  List<TrackPoint> get points => List.unmodifiable(_points);
  Duration get movingDuration => _movingDuration;
  double get distanceMeters => _distanceMeters;
  double get elevationGainMeters => GeoMath.elevationGainMeters(_points);
  double? get currentPaceSecondsPerKm =>
      GeoMath.paceSecondsPerKm(_distanceMeters, _movingDuration);
  String? get errorMessage => _errorMessage;
  int get filteredOutlierCount => _filteredOutlierCount;
  bool get isActive =>
      _status == RunTrackingStatus.acquiringGps ||
      _status == RunTrackingStatus.running ||
      _status == RunTrackingStatus.paused ||
      _status == RunTrackingStatus.gpsLost;

  Future<void> startRun() async {
    if (isActive) return;
    _errorMessage = null;
    try {
      await _locationService.ensurePermissionAndService();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return;
    }

    _points.clear();
    _distanceMeters = 0.0;
    _movingDuration = Duration.zero;
    _filteredOutlierCount = 0;
    _startedAt = DateTime.now().toUtc();
    _lastPointAt = DateTime.now().toUtc();
    _status = RunTrackingStatus.acquiringGps;
    notifyListeners();

    _gpsSub = _locationService.watchPositionStream().listen(
      _onTrackPointReceived,
      onError: (Object err) {
        _errorMessage = 'GPS 信号异常：$err';
        if (_status == RunTrackingStatus.running ||
            _status == RunTrackingStatus.acquiringGps) {
          _status = RunTrackingStatus.gpsLost;
        }
        notifyListeners();
      },
    );

    _ticker = Timer.periodic(AppConstants.tickerInterval, (_) => _onTick());
  }

  void pauseRun() {
    if (_status != RunTrackingStatus.running &&
        _status != RunTrackingStatus.gpsLost) {
      return;
    }
    _status = RunTrackingStatus.paused;
    notifyListeners();
  }

  void resumeRun() {
    if (_status != RunTrackingStatus.paused) return;
    _lastPointAt = DateTime.now().toUtc();
    _status = RunTrackingStatus.running;
    notifyListeners();
  }

  /// 结束跑步并生成可持久化的 RunSession
  Future<RunSession?> stopAndBuildSession({String? customTitle}) async {
    await _gpsSub?.cancel();
    _gpsSub = null;
    _ticker?.cancel();
    _ticker = null;

    final started = _startedAt;
    if (started == null || _points.isEmpty) {
      _status = RunTrackingStatus.idle;
      notifyListeners();
      return null;
    }

    _status = RunTrackingStatus.finished;
    final ended = DateTime.now().toUtc();
    final session = RunSession(
      id: 'run_${started.millisecondsSinceEpoch}',
      title: (customTitle != null && customTitle.trim().isNotEmpty)
          ? customTitle.trim()
          : '校园跑 ${started.toLocal().month}月${started.toLocal().day}日',
      startedAt: started,
      endedAt: ended,
      distanceMeters: _distanceMeters,
      movingDuration: _movingDuration,
      elevationGainMeters: elevationGainMeters,
      sourceDevice: Platform.operatingSystem,
      points: List<TrackPoint>.from(_points),
    );
    notifyListeners();
    return session;
  }

  void resetToIdle() {
    _points.clear();
    _distanceMeters = 0.0;
    _movingDuration = Duration.zero;
    _filteredOutlierCount = 0;
    _startedAt = null;
    _lastPointAt = null;
    _errorMessage = null;
    _status = RunTrackingStatus.idle;
    notifyListeners();
  }

  void _onTrackPointReceived(TrackPoint point) {
    if (_status == RunTrackingStatus.paused ||
        _status == RunTrackingStatus.idle ||
        _status == RunTrackingStatus.finished) {
      return;
    }

    // 首个有效点到达：从等待定位切换到跑步中
    if (_points.isEmpty) {
      if (point.accuracy != null &&
          point.accuracy! > AppConstants.maxAcceptableAccuracyMeters) {
        _filteredOutlierCount++;
        notifyListeners();
        return;
      }
      _points.add(point);
      _lastPointAt = DateTime.now().toUtc();
      _status = RunTrackingStatus.running;
      _errorMessage = null;
      notifyListeners();
      return;
    }

    final previous = _points.last;
    if (GeoMath.isOutlierPoint(
      previous: previous,
      candidate: point,
      maxSpeedMps: AppConstants.maxHumanRunningSpeedMps,
      maxAccuracyMeters: AppConstants.maxAcceptableAccuracyMeters,
    )) {
      _filteredOutlierCount++;
      notifyListeners();
      return;
    }

    final segmentDist = GeoMath.haversineDistanceMeters(
      previous.latitude,
      previous.longitude,
      point.latitude,
      point.longitude,
    );

    if (segmentDist >= AppConstants.minDistanceFilterMeters) {
      _distanceMeters += segmentDist;
      _points.add(point);
    }

    _lastPointAt = DateTime.now().toUtc();
    if (_status == RunTrackingStatus.gpsLost) {
      _status = RunTrackingStatus.running;
      _errorMessage = null;
    }
    notifyListeners();
  }

  void _onTick() {
    if (_status == RunTrackingStatus.running) {
      _movingDuration += AppConstants.tickerInterval;
      if (_lastPointAt != null &&
          DateTime.now().toUtc().difference(_lastPointAt!) > _gpsTimeout) {
        _status = RunTrackingStatus.gpsLost;
        _errorMessage = 'GPS 信号暂时丢失，正在自动尝试恢复...';
      }
      notifyListeners();
    }
  }

  @override
  void dispose() {
    unawaited(_gpsSub?.cancel());
    _ticker?.cancel();
    super.dispose();
  }
}
