import 'dart:convert';

import '../../core/utils/geo_math.dart';
import 'track_point.dart';

/// 校园规划路线实体（用于桌面端路线编辑器与手机端参考路线）
class CampusRoute {
  const CampusRoute({
    required this.id,
    required this.name,
    required this.createdAt,
    required this.waypoints,
    this.description = '',
  });

  final String id;
  final String name;
  final DateTime createdAt;
  final List<TrackPoint> waypoints;
  final String description;

  double get totalDistanceMeters => GeoMath.totalDistanceMeters(waypoints);

  Map<String, Object?> toDbMap() => {
        'id': id,
        'name': name,
        'description': description,
        'created_at_ms': createdAt.toUtc().millisecondsSinceEpoch,
        'waypoints_json': jsonEncode(waypoints.map((e) => e.toJson()).toList()),
      };

  factory CampusRoute.fromDbMap(Map<String, Object?> map) {
    final decoded =
        jsonDecode(map['waypoints_json'] as String) as List<dynamic>;
    return CampusRoute(
      id: map['id'] as String,
      name: map['name'] as String,
      description: (map['description'] as String?) ?? '',
      createdAt: DateTime.fromMillisecondsSinceEpoch(
        (map['created_at_ms'] as num).toInt(),
        isUtc: true,
      ),
      waypoints: decoded
          .map((e) => TrackPoint.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}
