/// 单个 WGS84 轨迹采样点
class TrackPoint {
  const TrackPoint({
    required this.latitude,
    required this.longitude,
    required this.timestamp,
    this.altitude,
    this.accuracy,
    this.speedMps,
  });

  final double latitude;
  final double longitude;
  final DateTime timestamp;
  final double? altitude;
  final double? accuracy;
  final double? speedMps;

  Map<String, Object?> toMap({required String sessionId, required int seq}) {
    return {
      'session_id': sessionId,
      'seq': seq,
      'latitude': latitude,
      'longitude': longitude,
      'altitude': altitude,
      'accuracy': accuracy,
      'speed_mps': speedMps,
      'timestamp_ms': timestamp.toUtc().millisecondsSinceEpoch,
    };
  }

  factory TrackPoint.fromMap(Map<String, Object?> map) {
    return TrackPoint(
      latitude: (map['latitude'] as num).toDouble(),
      longitude: (map['longitude'] as num).toDouble(),
      altitude: (map['altitude'] as num?)?.toDouble(),
      accuracy: (map['accuracy'] as num?)?.toDouble(),
      speedMps: (map['speed_mps'] as num?)?.toDouble(),
      timestamp: DateTime.fromMillisecondsSinceEpoch(
        (map['timestamp_ms'] as num).toInt(),
        isUtc: true,
      ),
    );
  }

  Map<String, dynamic> toJson() => {
        'lat': latitude,
        'lng': longitude,
        'alt': altitude,
        'acc': accuracy,
        'spd': speedMps,
        'ts': timestamp.toUtc().toIso8601String(),
      };

  factory TrackPoint.fromJson(Map<String, dynamic> json) => TrackPoint(
        latitude: (json['lat'] as num).toDouble(),
        longitude: (json['lng'] as num).toDouble(),
        altitude: (json['alt'] as num?)?.toDouble(),
        accuracy: (json['acc'] as num?)?.toDouble(),
        speedMps: (json['spd'] as num?)?.toDouble(),
        timestamp: DateTime.parse(json['ts'] as String).toUtc(),
      );
}
