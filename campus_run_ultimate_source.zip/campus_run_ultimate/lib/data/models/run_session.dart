import '../../core/utils/geo_math.dart';
import 'track_point.dart';

/// 一次完整的校园跑运动记录
class RunSession {
  const RunSession({
    required this.id,
    required this.title,
    required this.startedAt,
    required this.endedAt,
    required this.distanceMeters,
    required this.movingDuration,
    required this.elevationGainMeters,
    required this.sourceDevice,
    this.notes = '',
    this.points = const [],
  });

  final String id;
  final String title;
  final DateTime startedAt;
  final DateTime endedAt;
  final double distanceMeters;
  final Duration movingDuration;
  final double elevationGainMeters;
  final String sourceDevice;
  final String notes;
  final List<TrackPoint> points;

  double? get averagePaceSecondsPerKm =>
      GeoMath.paceSecondsPerKm(distanceMeters, movingDuration);

  List<double> get splitPaces => GeoMath.kilometerSplitPaces(points);

  RunSession copyWith({
    String? title,
    String? notes,
    List<TrackPoint>? points,
  }) {
    return RunSession(
      id: id,
      title: title ?? this.title,
      startedAt: startedAt,
      endedAt: endedAt,
      distanceMeters: distanceMeters,
      movingDuration: movingDuration,
      elevationGainMeters: elevationGainMeters,
      sourceDevice: sourceDevice,
      notes: notes ?? this.notes,
      points: points ?? this.points,
    );
  }

  Map<String, Object?> toDbMap() => {
        'id': id,
        'title': title,
        'started_at_ms': startedAt.toUtc().millisecondsSinceEpoch,
        'ended_at_ms': endedAt.toUtc().millisecondsSinceEpoch,
        'distance_meters': distanceMeters,
        'moving_seconds': movingDuration.inSeconds,
        'elevation_gain_meters': elevationGainMeters,
        'source_device': sourceDevice,
        'notes': notes,
      };

  factory RunSession.fromDbMap(
    Map<String, Object?> map, {
    List<TrackPoint> points = const [],
  }) {
    return RunSession(
      id: map['id'] as String,
      title: map['title'] as String,
      startedAt: DateTime.fromMillisecondsSinceEpoch(
        (map['started_at_ms'] as num).toInt(),
        isUtc: true,
      ),
      endedAt: DateTime.fromMillisecondsSinceEpoch(
        (map['ended_at_ms'] as num).toInt(),
        isUtc: true,
      ),
      distanceMeters: (map['distance_meters'] as num).toDouble(),
      movingDuration: Duration(seconds: (map['moving_seconds'] as num).toInt()),
      elevationGainMeters: (map['elevation_gain_meters'] as num).toDouble(),
      sourceDevice: (map['source_device'] as String?) ?? 'unknown',
      notes: (map['notes'] as String?) ?? '',
      points: points,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'startedAt': startedAt.toUtc().toIso8601String(),
        'endedAt': endedAt.toUtc().toIso8601String(),
        'distanceMeters': distanceMeters,
        'movingSeconds': movingDuration.inSeconds,
        'elevationGainMeters': elevationGainMeters,
        'sourceDevice': sourceDevice,
        'notes': notes,
        'points': points.map((e) => e.toJson()).toList(),
      };

  factory RunSession.fromJson(Map<String, dynamic> json) => RunSession(
        id: json['id'] as String,
        title: json['title'] as String,
        startedAt: DateTime.parse(json['startedAt'] as String).toUtc(),
        endedAt: DateTime.parse(json['endedAt'] as String).toUtc(),
        distanceMeters: (json['distanceMeters'] as num).toDouble(),
        movingDuration: Duration(seconds: (json['movingSeconds'] as num).toInt()),
        elevationGainMeters: (json['elevationGainMeters'] as num).toDouble(),
        sourceDevice: (json['sourceDevice'] as String?) ?? 'imported',
        notes: (json['notes'] as String?) ?? '',
        points: ((json['points'] as List<dynamic>?) ?? const [])
            .map((e) => TrackPoint.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}
