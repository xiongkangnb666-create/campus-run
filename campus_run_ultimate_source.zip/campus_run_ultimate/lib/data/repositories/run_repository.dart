import 'dart:io';

import '../models/campus_route.dart';
import '../models/run_session.dart';
import '../services/gpx_kml_codec.dart';
import '../services/local_database.dart';
import '../services/sync_transfer_service.dart';

/// 运动记录与路线数据仓库（统一管理 SQLite、GPX/KML、同步包）
class RunRepository {
  RunRepository({
    LocalDatabase? database,
    GpxKmlCodec? codec,
    SyncTransferService? syncService,
  })  : _db = database ?? LocalDatabase.instance,
        _codec = codec ?? const GpxKmlCodec(),
        _syncService = syncService ?? const SyncTransferService();

  final LocalDatabase _db;
  final GpxKmlCodec _codec;
  final SyncTransferService _syncService;

  Future<List<RunSession>> fetchSessions({bool includePoints = false}) =>
      _db.listSessions(includePoints: includePoints);

  Future<RunSession> loadSessionWithPoints(RunSession session) async {
    if (session.points.isNotEmpty) return session;
    final points = await _db.getSessionPoints(session.id);
    return session.copyWith(points: points);
  }

  Future<void> saveSession(RunSession session) => _db.saveSession(session);

  Future<void> deleteSession(String id) => _db.deleteSession(id);

  Future<List<CampusRoute>> fetchRoutes() => _db.listRoutes();

  Future<void> saveRoute(CampusRoute route) => _db.saveRoute(route);

  Future<void> deleteRoute(String id) => _db.deleteRoute(id);

  Future<RunSession> importGpxOrKmlFile(File file) async {
    final content = await file.readAsString();
    final lower = file.path.toLowerCase();
    final id = 'imp_${DateTime.now().millisecondsSinceEpoch}';
    final session = lower.endsWith('.kml')
        ? _codec.decodeKml(content, fallbackId: id)
        : _codec.decodeGpx(content, fallbackId: id);
    await _db.saveSession(session);
    return session;
  }

  Future<File> exportSessionToGpx(RunSession session, File targetFile) async {
    final full = await loadSessionWithPoints(session);
    final xml = _codec.encodeGpx(full);
    return targetFile.writeAsString(xml);
  }

  Future<File> exportSessionToKml(RunSession session, File targetFile) async {
    final full = await loadSessionWithPoints(session);
    final xml = _codec.encodeKml(full);
    return targetFile.writeAsString(xml);
  }

  Future<File> exportSyncBundle(File targetFile, {required String deviceTag}) async {
    final all = await _db.listSessions(includePoints: true);
    final bundle = _syncService.createSyncBundle(all, exportedFrom: deviceTag);
    return targetFile.writeAsString(bundle);
  }

  Future<int> importSyncBundle(File sourceFile) async {
    final raw = await sourceFile.readAsString();
    final imported = _syncService.parseSyncBundle(raw);
    for (final session in imported) {
      await _db.saveSession(session);
    }
    return imported.length;
  }
}
