import 'package:xml/xml.dart';

import '../../core/errors/app_exception.dart';
import '../../core/utils/geo_math.dart';
import '../models/run_session.dart';
import '../models/track_point.dart';

/// 标准 GPX 1.1 与 KML 2.2 导入导出编解码器
class GpxKmlCodec {
  const GpxKmlCodec();

  /// 将 RunSession 导出为标准 GPX 1.1 XML 字符串
  String encodeGpx(RunSession session) {
    final builder = XmlBuilder();
    builder.processing('xml', 'version="1.0" encoding="UTF-8"');
    builder.element(
      'gpx',
      attributes: {
        'version': '1.1',
        'creator': 'Campus Run Ultimate',
        'xmlns': 'http://www.topografix.com/GPX/1/1',
      },
      nest: () {
        builder.element('metadata', nest: () {
          builder.element('name', nest: session.title);
          builder.element('time', nest: session.startedAt.toUtc().toIso8601String());
        });
        builder.element('trk', nest: () {
          builder.element('name', nest: session.title);
          if (session.notes.isNotEmpty) {
            builder.element('desc', nest: session.notes);
          }
          builder.element('trkseg', nest: () {
            for (final pt in session.points) {
              builder.element(
                'trkpt',
                attributes: {
                  'lat': pt.latitude.toStringAsFixed(7),
                  'lon': pt.longitude.toStringAsFixed(7),
                },
                nest: () {
                  if (pt.altitude != null) {
                    builder.element('ele', nest: pt.altitude!.toStringAsFixed(2));
                  }
                  builder.element('time', nest: pt.timestamp.toUtc().toIso8601String());
                },
              );
            }
          });
        });
      },
    );
    return builder.buildDocument().toXmlString(pretty: true);
  }

  /// 解析 GPX 1.1 XML 字符串为 RunSession
  RunSession decodeGpx(String xmlContent, {required String fallbackId}) {
    try {
      final doc = XmlDocument.parse(xmlContent);
      final trkpts = doc.findAllElements('trkpt').toList();
      final rtepts = trkpts.isEmpty ? doc.findAllElements('rtept').toList() : const <XmlElement>[];
      final rawNodes = trkpts.isNotEmpty ? trkpts : rtepts;

      if (rawNodes.isEmpty) {
        throw const FileFormatException('GPX 文件中未找到有效轨迹点 (trkpt / rtept)');
      }

      final nameElem = doc.findAllElements('name').firstOrNull;
      final title = (nameElem?.innerText.trim().isNotEmpty ?? false)
          ? nameElem!.innerText.trim()
          : '导入的 GPX 轨迹';

      final baseTime = DateTime.now().toUtc();
      final points = <TrackPoint>[];
      for (var i = 0; i < rawNodes.length; i++) {
        final node = rawNodes[i];
        final lat = double.tryParse(node.getAttribute('lat') ?? '');
        final lon = double.tryParse(node.getAttribute('lon') ?? '');
        if (lat == null || lon == null) continue;
        final eleStr = node.getElement('ele')?.innerText.trim();
        final timeStr = node.getElement('time')?.innerText.trim();
        final ts = timeStr != null
            ? (DateTime.tryParse(timeStr)?.toUtc() ??
                baseTime.add(Duration(seconds: i * 3)))
            : baseTime.add(Duration(seconds: i * 3));
        points.add(
          TrackPoint(
            latitude: lat,
            longitude: lon,
            altitude: eleStr != null ? double.tryParse(eleStr) : null,
            timestamp: ts,
          ),
        );
      }

      if (points.length < 2) {
        throw const FileFormatException('GPX 有效坐标点不足 2 个，无法生成轨迹');
      }

      final startedAt = points.first.timestamp;
      final endedAt = points.last.timestamp;
      final moving = endedAt.difference(startedAt).isNegative
          ? Duration.zero
          : endedAt.difference(startedAt);

      return RunSession(
        id: fallbackId,
        title: title,
        startedAt: startedAt,
        endedAt: endedAt,
        distanceMeters: GeoMath.totalDistanceMeters(points),
        movingDuration: moving,
        elevationGainMeters: GeoMath.elevationGainMeters(points),
        sourceDevice: 'GPX导入',
        points: points,
      );
    } on FileFormatException {
      rethrow;
    } catch (e) {
      throw FileFormatException('GPX 文件解析失败', e);
    }
  }

  /// 将 RunSession 导出为标准 KML 2.2 XML 字符串
  String encodeKml(RunSession session) {
    final coordBuffer = StringBuffer();
    for (final pt in session.points) {
      final alt = (pt.altitude ?? 0.0).toStringAsFixed(2);
      coordBuffer.writeln(
        '${pt.longitude.toStringAsFixed(7)},${pt.latitude.toStringAsFixed(7)},$alt',
      );
    }

    final builder = XmlBuilder();
    builder.processing('xml', 'version="1.0" encoding="UTF-8"');
    builder.element(
      'kml',
      attributes: {'xmlns': 'http://www.opengis.net/kml/2.2'},
      nest: () {
        builder.element('Document', nest: () {
          builder.element('name', nest: session.title);
          builder.element('Placemark', nest: () {
            builder.element('name', nest: session.title);
            builder.element('description', nest: session.notes);
            builder.element('LineString', nest: () {
              builder.element('tessellate', nest: '1');
              builder.element('coordinates', nest: coordBuffer.toString().trim());
            });
          });
        });
      },
    );
    return builder.buildDocument().toXmlString(pretty: true);
  }

  /// 解析 KML 2.2 XML 字符串为 RunSession
  RunSession decodeKml(String xmlContent, {required String fallbackId}) {
    try {
      final doc = XmlDocument.parse(xmlContent);
      final coordElems = doc.findAllElements('coordinates').toList();
      if (coordElems.isEmpty) {
        throw const FileFormatException('KML 文件中未找到 coordinates 节点');
      }

      final nameElem = doc.findAllElements('name').firstOrNull;
      final title = (nameElem?.innerText.trim().isNotEmpty ?? false)
          ? nameElem!.innerText.trim()
          : '导入的 KML 轨迹';

      final baseTime = DateTime.now().toUtc();
      final points = <TrackPoint>[];
      var seq = 0;

      for (final elem in coordElems) {
        final tokens = elem.innerText
            .trim()
            .split(RegExp(r'\s+'))
            .where((t) => t.isNotEmpty);
        for (final token in tokens) {
          final parts = token.split(',');
          if (parts.length < 2) continue;
          final lon = double.tryParse(parts[0]);
          final lat = double.tryParse(parts[1]);
          final alt = parts.length >= 3 ? double.tryParse(parts[2]) : null;
          if (lat == null || lon == null) continue;
          points.add(
            TrackPoint(
              latitude: lat,
              longitude: lon,
              altitude: alt,
              timestamp: baseTime.add(Duration(seconds: seq * 3)),
            ),
          );
          seq++;
        }
      }

      if (points.length < 2) {
        throw const FileFormatException('KML 有效坐标点不足 2 个');
      }

      return RunSession(
        id: fallbackId,
        title: title,
        startedAt: points.first.timestamp,
        endedAt: points.last.timestamp,
        distanceMeters: GeoMath.totalDistanceMeters(points),
        movingDuration: points.last.timestamp.difference(points.first.timestamp),
        elevationGainMeters: GeoMath.elevationGainMeters(points),
        sourceDevice: 'KML导入',
        points: points,
      );
    } on FileFormatException {
      rethrow;
    } catch (e) {
      throw FileFormatException('KML 文件解析失败', e);
    }
  }
}
