import 'dart:async';
import 'dart:io';

import 'package:geolocator/geolocator.dart';

import '../../core/constants/app_constants.dart';
import '../../core/errors/app_exception.dart';
import '../models/track_point.dart';

/// 真实 GPS 定位服务抽象（便于单元测试与跨平台适配）
abstract class LocationService {
  Future<void> ensurePermissionAndService();
  Stream<TrackPoint> watchPositionStream();
}

/// 基于 Baseflow/flutter-geolocator 的真实 GPS 采集实现
/// 注意：本服务仅读取操作系统真实传感器位置，不包含任何模拟定位或作弊逻辑。
class GeolocatorLocationService implements LocationService {
  const GeolocatorLocationService();

  @override
  Future<void> ensurePermissionAndService() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw const GpsServiceException('系统定位服务未开启，请先在设置中打开 GPS 定位。');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const GpsServiceException('定位权限被拒绝，无法采集真实运动轨迹。');
    }
    if (permission == LocationPermission.deniedForever) {
      throw const GpsServiceException(
        '定位权限已被永久拒绝，请在系统应用设置中手动开启“始终允许”或“使用期间允许”。',
      );
    }
  }

  @override
  Stream<TrackPoint> watchPositionStream() {
    final LocationSettings settings;
    if (Platform.isAndroid) {
      settings = AndroidSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: AppConstants.minDistanceFilterMeters.round(),
        intervalDuration: const Duration(seconds: 1),
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationTitle: '校园跑终极版 - 正在记录运动轨迹',
          notificationText: '后台真实 GPS 采集中，点击返回运动界面',
          enableWakeLock: true,
        ),
      );
    } else {
      settings = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: AppConstants.minDistanceFilterMeters.round(),
      );
    }

    return Geolocator.getPositionStream(locationSettings: settings).map(
      (pos) => TrackPoint(
        latitude: pos.latitude,
        longitude: pos.longitude,
        altitude: pos.altitude,
        accuracy: pos.accuracy,
        speedMps: pos.speed,
        timestamp: pos.timestamp.toUtc(),
      ),
    );
  }
}
