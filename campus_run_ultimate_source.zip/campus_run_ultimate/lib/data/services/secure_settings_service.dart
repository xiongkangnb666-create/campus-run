import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../../core/constants/app_constants.dart';

/// 基于系统密钥链/Windows Credential Manager 的安全配置存储
class SecureSettingsService {
  SecureSettingsService({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _storage;

  Future<double> getDailyGoalKm() async {
    final raw = await _storage.read(key: AppConstants.keyDailyGoalKm);
    return double.tryParse(raw ?? '') ?? 3.0;
  }

  Future<void> setDailyGoalKm(double km) async {
    await _storage.write(
      key: AppConstants.keyDailyGoalKm,
      value: km.toStringAsFixed(1),
    );
  }

  Future<bool> isOfflineMapOnly() async {
    final raw = await _storage.read(key: AppConstants.keyOfflineMapOnly);
    return raw == 'true';
  }

  Future<void> setOfflineMapOnly(bool enabled) async {
    await _storage.write(
      key: AppConstants.keyOfflineMapOnly,
      value: enabled.toString(),
    );
  }

  Future<String> getDeviceTag() async {
    final raw = await _storage.read(key: AppConstants.keySyncDeviceTag);
    return (raw != null && raw.isNotEmpty) ? raw : 'CampusRun-Device';
  }

  Future<void> setDeviceTag(String tag) async {
    await _storage.write(key: AppConstants.keySyncDeviceTag, value: tag.trim());
  }
}
