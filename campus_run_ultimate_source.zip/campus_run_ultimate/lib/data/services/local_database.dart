import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_common_ffi.dart';

import '../../core/errors/app_exception.dart';
import '../models/campus_route.dart';
import '../models/run_session.dart';
import '../models/track_point.dart';

/// 跨平台本地 SQLite 数据库（Android 使用 sqflite，Windows 11 使用 sqflite_common_ffi）
class LocalDatabase {
  LocalDatabase._();

  static final LocalDatabase instance = LocalDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _open();
    return _db!;
  }

  Future<Database> _open() async {
    try {
      if (Platform.isWindows || Platform.isLinux) {
        sqfliteFfiInit();
        databaseFactory = databaseFactoryFfi;
      }
      final dir = await getApplicationSupportDirectory();
      final dbPath = p.join(dir.path, 'campus_run_ultimate.db');
      return await openDatabase(
        dbPath,
        version: 1,
        onCreate: (db, version) async {
          await db.execute('''
            CREATE TABLE run_sessions (
              id TEXT PRIMARY KEY,
              title TEXT NOT NULL,
              started_at_ms INTEGER NOT NULL,
              ended_at_ms INTEGER NOT NULL,
              distance_meters REAL NOT NULL,
              moving_seconds INTEGER NOT NULL,
              elevation_gain_meters REAL NOT NULL,
              source_device TEXT NOT NULL,
              notes TEXT NOT NULL DEFAULT ''
            )
          ''');
          await db.execute('''
            CREATE TABLE track_points (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              session_id TEXT NOT NULL,
              seq INTEGER NOT NULL,
              latitude REAL NOT NULL,
              longitude REAL NOT NULL,
              altitude REAL,
              accuracy REAL,
              speed_mps REAL,
              timestamp_ms INTEGER NOT NULL,
              FOREIGN KEY(session_id) REFERENCES run_sessions(id) ON DELETE CASCADE
            )
          ''');
          await db.execute(
            'CREATE INDEX idx_track_points_session ON track_points(session_id, seq)',
          );
          await db.execute('''
            CREATE TABLE campus_routes (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              description TEXT NOT NULL DEFAULT '',
              created_at_ms INTEGER NOT NULL,
              waypoints_json TEXT NOT NULL
            )
          ''');
        },
      );
    } catch (e) {
      throw StorageException('本地数据库初始化失败', e);
    }
  }

  Future<void> saveSession(RunSession session) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.insert(
        'run_sessions',
        session.toDbMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      await txn.delete(
        'track_points',
        where: 'session_id = ?',
        whereArgs: [session.id],
      );
      final batch = txn.batch();
      for (var i = 0; i < session.points.length; i++) {
        batch.insert(
          'track_points',
          session.points[i].toMap(sessionId: session.id, seq: i),
        );
      }
      await batch.commit(noResult: true);
    });
  }

  Future<List<RunSession>> listSessions({bool includePoints = false}) async {
    final db = await database;
    final rows = await db.query(
      'run_sessions',
      orderBy: 'started_at_ms DESC',
    );
    final results = <RunSession>[];
    for (final row in rows) {
      final id = row['id'] as String;
      final points = includePoints ? await getSessionPoints(id) : const <TrackPoint>[];
      results.add(RunSession.fromDbMap(row, points: points));
    }
    return results;
  }

  Future<List<TrackPoint>> getSessionPoints(String sessionId) async {
    final db = await database;
    final rows = await db.query(
      'track_points',
      where: 'session_id = ?',
      whereArgs: [sessionId],
      orderBy: 'seq ASC',
    );
    return rows.map(TrackPoint.fromMap).toList();
  }

  Future<void> deleteSession(String sessionId) async {
    final db = await database;
    await db.delete('track_points', where: 'session_id = ?', whereArgs: [sessionId]);
    await db.delete('run_sessions', where: 'id = ?', whereArgs: [sessionId]);
  }

  Future<void> saveRoute(CampusRoute route) async {
    final db = await database;
    await db.insert(
      'campus_routes',
      route.toDbMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<CampusRoute>> listRoutes() async {
    final db = await database;
    final rows = await db.query('campus_routes', orderBy: 'created_at_ms DESC');
    return rows.map(CampusRoute.fromDbMap).toList();
  }

  Future<void> deleteRoute(String routeId) async {
    final db = await database;
    await db.delete('campus_routes', where: 'id = ?', whereArgs: [routeId]);
  }
}
