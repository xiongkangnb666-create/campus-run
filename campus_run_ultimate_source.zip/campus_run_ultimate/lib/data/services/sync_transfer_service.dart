import 'dart:convert';

import 'package:crypto/crypto.dart';

import '../../core/errors/app_exception.dart';
import '../models/run_session.dart';

/// 手机端与 Windows 桌面端离线同步包编解码服务（含 SHA-256 完整性校验）
class SyncTransferService {
  const SyncTransferService();

  static const int currentSchemaVersion = 1;

  /// 将多条跑步记录打包为带完整性校验的离线 JSON 同步包
  String createSyncBundle(
    List<RunSession> sessions, {
    required String exportedFrom,
  }) {
    final payload = {
      'schemaVersion': currentSchemaVersion,
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'exportedFrom': exportedFrom,
      'sessions': sessions.map((s) => s.toJson()).toList(),
    };
    final payloadJson = jsonEncode(payload);
    final checksum = sha256.convert(utf8.encode(payloadJson)).toString();
    return const JsonEncoder.withIndent('  ').convert({
      'checksumSha256': checksum,
      'payload': payload,
    });
  }

  /// 解析并校验离线同步包，防止文件损坏或篡改
  List<RunSession> parseSyncBundle(String rawJson) {
    try {
      final root = jsonDecode(rawJson) as Map<String, dynamic>;
      final expectedChecksum = root['checksumSha256'] as String?;
      final payload = root['payload'] as Map<String, dynamic>?;
      if (expectedChecksum == null || payload == null) {
        throw const SyncIntegrityException('同步包缺少必要字段 (checksumSha256 / payload)');
      }

      final canonicalPayload = jsonEncode(payload);
      final actualChecksum =
          sha256.convert(utf8.encode(canonicalPayload)).toString();
      if (actualChecksum != expectedChecksum) {
        throw const SyncIntegrityException('同步包 SHA-256 校验失败，文件可能已损坏。');
      }

      final sessionsRaw = (payload['sessions'] as List<dynamic>?) ?? const [];
      return sessionsRaw
          .map((e) => RunSession.fromJson(e as Map<String, dynamic>))
          .toList();
    } on SyncIntegrityException {
      rethrow;
    } catch (e) {
      throw SyncIntegrityException('无法解析离线同步包', e);
    }
  }
}
