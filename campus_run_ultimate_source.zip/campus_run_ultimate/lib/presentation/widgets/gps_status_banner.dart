import 'package:flutter/material.dart';

import '../../domain/tracking/run_tracker_controller.dart';

/// GPS 信号与运动状态横幅
class GpsStatusBanner extends StatelessWidget {
  const GpsStatusBanner({
    super.key,
    required this.status,
    this.errorMessage,
    this.filteredOutlierCount = 0,
  });

  final RunTrackingStatus status;
  final String? errorMessage;
  final int filteredOutlierCount;

  @override
  Widget build(BuildContext context) {
    final (Color bg, Color fg, IconData icon, String text) = switch (status) {
      RunTrackingStatus.idle => (
          Theme.of(context).colorScheme.surfaceContainerHighest,
          Theme.of(context).colorScheme.onSurface,
          Icons.gps_not_fixed,
          '准备就绪：点击下方按钮开始真实 GPS 校园跑记录',
        ),
      RunTrackingStatus.acquiringGps => (
          Colors.amber.shade100,
          Colors.amber.shade900,
          Icons.gps_not_fixed,
          '正在搜索真实 GPS 卫星信号，请前往空旷户外区域...',
        ),
      RunTrackingStatus.running => (
          Colors.green.shade100,
          Colors.green.shade900,
          Icons.gps_fixed,
          'GPS 信号稳定 · 正在采集真实轨迹（已滤除异常漂移点 $filteredOutlierCount 个）',
        ),
      RunTrackingStatus.paused => (
          Colors.blue.shade100,
          Colors.blue.shade900,
          Icons.pause_circle,
          '运动已暂停 · 暂停期间不计入有效运动时长与里程',
        ),
      RunTrackingStatus.gpsLost => (
          Colors.red.shade100,
          Colors.red.shade900,
          Icons.gps_off,
          errorMessage ?? 'GPS 信号丢失，正在自动尝试重新锁定...',
        ),
      RunTrackingStatus.finished => (
          Colors.teal.shade100,
          Colors.teal.shade900,
          Icons.check_circle,
          '本次校园跑已完成并保存至本地数据库',
        ),
    };

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: fg, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              errorMessage != null && status == RunTrackingStatus.idle
                  ? errorMessage!
                  : text,
              style: TextStyle(color: fg, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }
}
