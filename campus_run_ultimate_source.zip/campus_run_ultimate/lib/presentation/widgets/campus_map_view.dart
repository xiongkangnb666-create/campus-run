import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../core/constants/app_constants.dart';
import '../../data/models/track_point.dart';

/// 可复用的跨平台地图组件（支持在线 OSM 瓦片与纯离线网格底图回退）
class CampusMapView extends StatelessWidget {
  const CampusMapView({
    super.key,
    required this.points,
    this.mapController,
    this.highlightedPoint,
    this.offlineOnly = false,
    this.onTapLatLng,
  });

  final List<TrackPoint> points;
  final MapController? mapController;
  final TrackPoint? highlightedPoint;
  final bool offlineOnly;
  final void Function(LatLng latLng)? onTapLatLng;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final polyPoints =
        points.map((p) => LatLng(p.latitude, p.longitude)).toList();

    final initialCenter = polyPoints.isNotEmpty
        ? polyPoints.last
        : const LatLng(
            AppConstants.defaultLatitude,
            AppConstants.defaultLongitude,
          );

    final markers = <Marker>[];
    if (polyPoints.isNotEmpty) {
      markers.add(
        Marker(
          point: polyPoints.first,
          width: 32,
          height: 32,
          child: const Icon(Icons.flag_circle, color: Colors.green, size: 30),
        ),
      );
      if (polyPoints.length > 1) {
        markers.add(
          Marker(
            point: polyPoints.last,
            width: 32,
            height: 32,
            child: const Icon(Icons.location_on, color: Colors.red, size: 30),
          ),
        );
      }
    }
    if (highlightedPoint != null) {
      markers.add(
        Marker(
          point: LatLng(
            highlightedPoint!.latitude,
            highlightedPoint!.longitude,
          ),
          width: 36,
          height: 36,
          child: Container(
            decoration: BoxDecoration(
              color: colorScheme.primary,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 3),
            ),
            child: const Icon(
              Icons.directions_run,
              color: Colors.white,
              size: 18,
            ),
          ),
        ),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Stack(
        children: [
          FlutterMap(
            mapController: mapController,
            options: MapOptions(
              initialCenter: initialCenter,
              initialZoom: AppConstants.defaultZoom,
              backgroundColor: colorScheme.surfaceContainerHighest,
              onTap: onTapLatLng == null
                  ? null
                  : (_, latLng) => onTapLatLng!(latLng),
            ),
            children: [
              if (!offlineOnly)
                TileLayer(
                  urlTemplate: AppConstants.osmTileUrl,
                  userAgentPackageName: AppConstants.osmUserAgentPackage,
                  maxZoom: 19,
                ),
              if (polyPoints.length >= 2)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: polyPoints,
                      strokeWidth: 4.5,
                      color: colorScheme.primary,
                    ),
                  ],
                ),
              if (markers.isNotEmpty) MarkerLayer(markers: markers),
            ],
          ),
          if (offlineOnly)
            Positioned(
              left: 12,
              top: 12,
              child: Chip(
                avatar: const Icon(Icons.cloud_off, size: 16),
                label: const Text('离线矢量视图模式'),
                backgroundColor: colorScheme.surface.withOpacity(0.92),
              ),
            ),
        ],
      ),
    );
  }
}
