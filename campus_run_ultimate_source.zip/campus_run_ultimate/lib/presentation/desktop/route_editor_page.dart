import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';

import '../../core/utils/formatters.dart';
import '../../core/utils/geo_math.dart';
import '../../data/models/campus_route.dart';
import '../../data/models/run_session.dart';
import '../../data/models/track_point.dart';
import '../../data/repositories/run_repository.dart';
import '../widgets/campus_map_view.dart';

/// Windows 11 桌面端校园路线编辑器（点击地图打点、撤销、保存、导出 GPX/KML）
class RouteEditorPage extends StatefulWidget {
  const RouteEditorPage({super.key});

  @override
  State<RouteEditorPage> createState() => _RouteEditorPageState();
}

class _RouteEditorPageState extends State<RouteEditorPage> {
  final TextEditingController _nameController =
      TextEditingController(text: '校园操场标准路线');
  final List<TrackPoint> _waypoints = [];
  bool _offlineOnly = false;

  void _addWaypoint(LatLng latLng) {
    setState(() {
      _waypoints.add(
        TrackPoint(
          latitude: latLng.latitude,
          longitude: latLng.longitude,
          timestamp: DateTime.now().toUtc(),
        ),
      );
    });
  }

  Future<void> _saveRoute() async {
    if (_waypoints.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请至少在地图上点击添加 2 个路线途经点')),
      );
      return;
    }
    final route = CampusRoute(
      id: 'route_${DateTime.now().millisecondsSinceEpoch}',
      name: _nameController.text.trim().isEmpty
          ? '未命名校园路线'
          : _nameController.text.trim(),
      createdAt: DateTime.now().toUtc(),
      waypoints: List<TrackPoint>.from(_waypoints),
    );
    await context.read<RunRepository>().saveRoute(route);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('路线“${route.name}”已保存至本地库')),
      );
    }
  }

  Future<void> _exportRoute(String ext) async {
    if (_waypoints.length < 2) return;
    final path = await FilePicker.platform.saveFile(
      dialogTitle: '导出规划路线为 ${ext.toUpperCase()}',
      fileName: 'campus_route.$ext',
    );
    if (path == null || !mounted) return;

    final now = DateTime.now().toUtc();
    final pseudoSession = RunSession(
      id: 'route_export_${now.millisecondsSinceEpoch}',
      title: _nameController.text.trim(),
      startedAt: now,
      endedAt: now,
      distanceMeters: GeoMath.totalDistanceMeters(_waypoints),
      movingDuration: Duration.zero,
      elevationGainMeters: 0.0,
      sourceDevice: 'Windows路线编辑器',
      points: _waypoints,
    );
    final repo = context.read<RunRepository>();
    if (ext == 'gpx') {
      await repo.exportSessionToGpx(pseudoSession, File(path));
    } else {
      await repo.exportSessionToKml(pseudoSession, File(path));
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('路线已导出至：$path')),
      );
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final totalDist = GeoMath.totalDistanceMeters(_waypoints);
    return Scaffold(
      appBar: AppBar(
        title: const Text('校园路线编辑器'),
        actions: [
          Row(
            children: [
              const Text('离线视图'),
              Switch(
                value: _offlineOnly,
                onChanged: (v) => setState(() => _offlineOnly = v),
              ),
            ],
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Row(
        children: [
          Expanded(
            flex: 3,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: CampusMapView(
                points: _waypoints,
                offlineOnly: _offlineOnly,
                onTapLatLng: _addWaypoint,
              ),
            ),
          ),
          SizedBox(
            width: 340,
            child: Card(
              margin: const EdgeInsets.fromLTRB(0, 16, 16, 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      '点击左侧地图依次添加路线节点',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _nameController,
                      decoration: const InputDecoration(
                        labelText: '路线名称',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text('节点数：${_waypoints.length} 个'),
                    Text('规划总里程：${Formatters.distanceKm(totalDist)}'),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        OutlinedButton.icon(
                          onPressed: _waypoints.isEmpty
                              ? null
                              : () => setState(() => _waypoints.removeLast()),
                          icon: const Icon(Icons.undo),
                          label: const Text('撤销一点'),
                        ),
                        OutlinedButton.icon(
                          onPressed: _waypoints.isEmpty
                              ? null
                              : () => setState(_waypoints.clear),
                          icon: const Icon(Icons.clear_all),
                          label: const Text('清空'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: _saveRoute,
                      icon: const Icon(Icons.save),
                      label: const Text('保存到路线库'),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.tonal(
                            onPressed: () => _exportRoute('gpx'),
                            child: const Text('导出 GPX'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton.tonal(
                            onPressed: () => _exportRoute('kml'),
                            child: const Text('导出 KML'),
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 24),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _waypoints.length,
                        itemBuilder: (_, idx) {
                          final pt = _waypoints[idx];
                          return ListTile(
                            dense: true,
                            title: Text('节点 #${idx + 1}'),
                            subtitle: Text(
                              '${pt.latitude.toStringAsFixed(6)}, ${pt.longitude.toStringAsFixed(6)}',
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
