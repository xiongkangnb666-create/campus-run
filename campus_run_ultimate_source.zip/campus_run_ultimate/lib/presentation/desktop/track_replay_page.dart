import 'dart:async';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/utils/formatters.dart';
import '../../data/models/run_session.dart';
import '../../data/repositories/run_repository.dart';
import '../widgets/campus_map_view.dart';

/// Windows 11 离线轨迹回放与分段配速分析页面
class TrackReplayPage extends StatefulWidget {
  const TrackReplayPage({super.key});

  @override
  State<TrackReplayPage> createState() => _TrackReplayPageState();
}

class _TrackReplayPageState extends State<TrackReplayPage> {
  List<RunSession> _sessions = const [];
  RunSession? _selected;
  int _cursor = 0;
  bool _playing = false;
  int _speedMultiplier = 2;
  bool _offlineOnly = true;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _loadSessions();
  }

  Future<void> _loadSessions() async {
    final repo = context.read<RunRepository>();
    final list = await repo.fetchSessions();
    if (!mounted) return;
    setState(() => _sessions = list);
    if (list.isNotEmpty) {
      await _selectSession(list.first);
    }
  }

  Future<void> _selectSession(RunSession summary) async {
    _stopTimer();
    final full =
        await context.read<RunRepository>().loadSessionWithPoints(summary);
    if (!mounted) return;
    setState(() {
      _selected = full;
      _cursor = 0;
      _playing = false;
    });
  }

  void _togglePlay() {
    final pts = _selected?.points ?? const [];
    if (pts.length < 2) return;
    if (_playing) {
      _stopTimer();
      setState(() => _playing = false);
      return;
    }
    setState(() => _playing = true);
    _timer = Timer.periodic(
      Duration(milliseconds: (500 ~/ _speedMultiplier).clamp(50, 500)),
      (_) {
        if (!mounted || _selected == null) return;
        setState(() {
          if (_cursor < _selected!.points.length - 1) {
            _cursor++;
          } else {
            _playing = false;
            _stopTimer();
          }
        });
      },
    );
  }

  void _stopTimer() {
    _timer?.cancel();
    _timer = null;
  }

  @override
  void dispose() {
    _stopTimer();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final points = _selected?.points ?? const [];
    final currentPoint =
        points.isNotEmpty ? points[_cursor.clamp(0, points.length - 1)] : null;
    final splits = _selected?.splitPaces ?? const [];

    return Scaffold(
      appBar: AppBar(
        title: const Text('离线轨迹回放与配速分析'),
        actions: [
          DropdownButton<String>(
            value: _selected?.id,
            hint: const Text('选择历史记录'),
            items: _sessions
                .map(
                  (s) => DropdownMenuItem(
                    value: s.id,
                    child: Text(
                      '${s.title} (${Formatters.distanceKm(s.distanceMeters)})',
                    ),
                  ),
                )
                .toList(),
            onChanged: (id) {
              final target = _sessions.where((s) => s.id == id).firstOrNull;
              if (target != null) {
                unawaited(_selectSession(target));
              }
            },
          ),
          const SizedBox(width: 12),
          Row(
            children: [
              const Text('纯离线模式'),
              Switch(
                value: _offlineOnly,
                onChanged: (v) => setState(() => _offlineOnly = v),
              ),
            ],
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: _selected == null
          ? const Center(child: Text('请先导入 GPX/KML 或同步手机运动记录以进行离线回放'))
          : Column(
              children: [
                Expanded(
                  flex: 3,
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: CampusMapView(
                            points: points,
                            highlightedPoint: currentPoint,
                            offlineOnly: _offlineOnly,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Card(
                          margin: const EdgeInsets.fromLTRB(0, 16, 16, 16),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  '海拔变化剖面（米）',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 12),
                                SizedBox(
                                  height: 160,
                                  child: points.isEmpty
                                      ? const Center(child: Text('无海拔数据'))
                                      : LineChart(
                                          LineChartData(
                                            titlesData: const FlTitlesData(
                                              show: false,
                                            ),
                                            lineBarsData: [
                                              LineChartBarData(
                                                isCurved: true,
                                                dotData:
                                                    const FlDotData(show: false),
                                                spots: [
                                                  for (var i = 0;
                                                      i < points.length;
                                                      i++)
                                                    FlSpot(
                                                      i.toDouble(),
                                                      points[i].altitude ?? 0.0,
                                                    ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                ),
                                const Divider(height: 24),
                                const Text(
                                  '每公里分段配速',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 8),
                                Expanded(
                                  child: splits.isEmpty
                                      ? const Text('当前轨迹里程不足 1 公里')
                                      : ListView.builder(
                                          itemCount: splits.length,
                                          itemBuilder: (_, idx) => ListTile(
                                            dense: true,
                                            leading: Text('第 ${idx + 1} 公里'),
                                            trailing: Text(
                                              Formatters.pace(splits[idx]),
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Card(
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    child: Row(
                      children: [
                        IconButton.filled(
                          onPressed: _togglePlay,
                          icon: Icon(
                            _playing ? Icons.pause : Icons.play_arrow,
                          ),
                        ),
                        const SizedBox(width: 12),
                        SegmentedButton<int>(
                          segments: const [
                            ButtonSegment(value: 1, label: Text('1x')),
                            ButtonSegment(value: 2, label: Text('2x')),
                            ButtonSegment(value: 5, label: Text('5x')),
                            ButtonSegment(value: 10, label: Text('10x')),
                          ],
                          selected: {_speedMultiplier},
                          onSelectionChanged: (s) {
                            setState(() => _speedMultiplier = s.first);
                            if (_playing) {
                              _togglePlay();
                              _togglePlay();
                            }
                          },
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Slider(
                            value: _cursor.toDouble(),
                            min: 0,
                            max: (points.length - 1).clamp(1, 999999).toDouble(),
                            onChanged: (v) =>
                                setState(() => _cursor = v.round()),
                          ),
                        ),
                        Text(
                          '${_cursor + 1} / ${points.length}',
                          style: const TextStyle(fontFeatures: []),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
