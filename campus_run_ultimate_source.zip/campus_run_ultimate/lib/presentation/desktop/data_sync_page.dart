import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/repositories/run_repository.dart';

/// Windows 11 桌面端手机记录同步与 GPX/KML 批量导入导出页面
class DataSyncPage extends StatelessWidget {
  const DataSyncPage({super.key});

  Future<void> _importGpxKml(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: const ['gpx', 'kml'],
    );
    if (result == null || !context.mounted) return;

    final repo = context.read<RunRepository>();
    var importedCount = 0;
    for (final f in result.files) {
      if (f.path == null) continue;
      await repo.importGpxOrKmlFile(File(f.path!));
      importedCount++;
    }
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('成功导入 $importedCount 个 GPX/KML 文件')),
      );
    }
  }

  Future<void> _importPhoneSyncBundle(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['json'],
    );
    final path = result?.files.single.path;
    if (path == null || !context.mounted) return;
    try {
      final count =
          await context.read<RunRepository>().importSyncBundle(File(path));
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('校验通过，已同步 $count 条手机端运动记录')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('同步包导入失败：$e')),
        );
      }
    }
  }

  Future<void> _exportBackupBundle(BuildContext context) async {
    final path = await FilePicker.platform.saveFile(
      dialogTitle: '导出全部运动数据备份包',
      fileName: 'campus_run_backup_${DateTime.now().millisecondsSinceEpoch}.json',
    );
    if (path == null || !context.mounted) return;
    await context.read<RunRepository>().exportSyncBundle(
          File(path),
          deviceTag: 'Windows11-Desktop',
        );
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('备份包已导出至：$path')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('手机记录同步与文件管理')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.phone_android),
              title: const Text('导入 Android 手机端离线同步包 (.json)'),
              subtitle: const Text('自动执行 SHA-256 完整性校验并合并至本地 SQLite 数据库'),
              trailing: FilledButton(
                onPressed: () => _importPhoneSyncBundle(context),
                child: const Text('选择同步包'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.map_outlined),
              title: const Text('批量导入 GPX / KML 轨迹文件'),
              subtitle: const Text('支持标准 GPX 1.1 与 KML 2.2 坐标轨迹文件'),
              trailing: FilledButton.tonal(
                onPressed: () => _importGpxKml(context),
                child: const Text('批量导入'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.backup_outlined),
              title: const Text('导出本地数据库离线备份'),
              subtitle: const Text('生成含 SHA-256 校验值的标准 JSON 同步包'),
              trailing: OutlinedButton(
                onPressed: () => _exportBackupBundle(context),
                child: const Text('导出备份'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
