import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/utils/formatters.dart';
import '../../data/models/run_session.dart';
import '../../data/repositories/run_repository.dart';
import '../widgets/stat_card.dart';

/// Windows 11 桌面端运动数据管理与统计仪表盘
class DesktopDashboardPage extends StatefulWidget {
  const DesktopDashboardPage({super.key});

  @override
  State<DesktopDashboardPage> createState() => _DesktopDashboardPageState();
}

class _DesktopDashboardPageState extends State<DesktopDashboardPage> {
  List<RunSession> _sessions = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final items = await context.read<RunRepository>().fetchSessions();
    if (!mounted) return;
    setState(() {
      _sessions = items;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final totalDist =
        _sessions.fold<double>(0.0, (acc, s) => acc + s.distanceMeters);
    final totalDuration = _sessions.fold<Duration>(
      Duration.zero,
      (acc, s) => acc + s.movingDuration,
    );
    final avgPace = totalDist > 0
        ? totalDuration.inSeconds / (totalDist / 1000.0)
        : null;

    final chartItems = _sessions.take(10).toList().reversed.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('运动数据仪表盘'),
        actions: [
          FilledButton.tonalIcon(
            onPressed: _load,
            icon: const Icon(Icons.refresh),
            label: const Text('刷新数据'),
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    SizedBox(
                      width: 220,
                      child: StatCard(
                        label: '累计运动次数',
                        value: '${_sessions.length} 次',
                        icon: Icons.event_available,
                      ),
                    ),
                    SizedBox(
                      width: 220,
                      child: StatCard(
                        label: '累计总里程',
                        value: Formatters.distanceKm(totalDist),
                        icon: Icons.route,
                      ),
                    ),
                    SizedBox(
                      width: 220,
                      child: StatCard(
                        label: '累计运动时长',
                        value: Formatters.duration(totalDuration),
                        icon: Icons.timer,
                      ),
                    ),
                    SizedBox(
                      width: 220,
                      child: StatCard(
                        label: '综合平均配速',
                        value: Formatters.pace(avgPace),
                        icon: Icons.speed,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '近期跑步里程趋势（公里）',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          height: 220,
                          child: chartItems.isEmpty
                              ? const Center(child: Text('暂无记录，请导入或同步手机端运动数据'))
                              : BarChart(
                                  BarChartData(
                                    barGroups: [
                                      for (var i = 0; i < chartItems.length; i++)
                                        BarChartGroupData(
                                          x: i,
                                          barRods: [
                                            BarChartRodData(
                                              toY: chartItems[i].distanceMeters /
                                                  1000.0,
                                              width: 22,
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .primary,
                                            ),
                                          ],
                                        ),
                                    ],
                                    titlesData: FlTitlesData(
                                      topTitles: const AxisTitles(
                                        sideTitles: SideTitles(showTitles: false),
                                      ),
                                      rightTitles: const AxisTitles(
                                        sideTitles: SideTitles(showTitles: false),
                                      ),
                                      bottomTitles: AxisTitles(
                                        sideTitles: SideTitles(
                                          showTitles: true,
                                          getTitlesWidget: (value, _) {
                                            final idx = value.toInt();
                                            if (idx < 0 ||
                                                idx >= chartItems.length) {
                                              return const SizedBox.shrink();
                                            }
                                            return Text(
                                              Formatters.shortDate(
                                                chartItems[idx].startedAt,
                                              ),
                                              style: const TextStyle(fontSize: 11),
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          '全部运动记录明细',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 12),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            columns: const [
                              DataColumn(label: Text('标题')),
                              DataColumn(label: Text('开始时间')),
                              DataColumn(label: Text('里程')),
                              DataColumn(label: Text('时长')),
                              DataColumn(label: Text('配速')),
                              DataColumn(label: Text('来源设备')),
                              DataColumn(label: Text('操作')),
                            ],
                            rows: _sessions
                                .map(
                                  (s) => DataRow(
                                    cells: [
                                      DataCell(Text(s.title)),
                                      DataCell(
                                        Text(Formatters.dateTime(s.startedAt)),
                                      ),
                                      DataCell(
                                        Text(
                                          Formatters.distanceKm(s.distanceMeters),
                                        ),
                                      ),
                                      DataCell(
                                        Text(
                                          Formatters.duration(s.movingDuration),
                                        ),
                                      ),
                                      DataCell(
                                        Text(
                                          Formatters.pace(
                                            s.averagePaceSecondsPerKm,
                                          ),
                                        ),
                                      ),
                                      DataCell(Text(s.sourceDevice)),
                                      DataCell(
                                        IconButton(
                                          icon: const Icon(Icons.delete_outline),
                                          tooltip: '删除记录',
                                          onPressed: () async {
                                            await context
                                                .read<RunRepository>()
                                                .deleteSession(s.id);
                                            await _load();
                                          },
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                                .toList(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
