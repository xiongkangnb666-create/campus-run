import 'package:flutter/material.dart';

import 'history_list_page.dart';
import 'mobile_routes_page.dart';
import 'run_tracking_page.dart';

/// Android 移动端底部导航外壳
class MobileShell extends StatefulWidget {
  const MobileShell({super.key});

  @override
  State<MobileShell> createState() => _MobileShellState();
}

class _MobileShellState extends State<MobileShell> {
  int _selectedIndex = 0;

  static const _pages = [
    RunTrackingPage(),
    HistoryListPage(),
    MobileRoutesPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _selectedIndex, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (idx) => setState(() => _selectedIndex = idx),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.directions_run_outlined),
            selectedIcon: Icon(Icons.directions_run),
            label: '运动记录',
          ),
          NavigationDestination(
            icon: Icon(Icons.history_outlined),
            selectedIcon: Icon(Icons.history),
            label: '历史记录',
          ),
          NavigationDestination(
            icon: Icon(Icons.import_export_outlined),
            selectedIcon: Icon(Icons.import_export),
            label: '导入与同步',
          ),
        ],
      ),
    );
  }
}
