import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/utils/formatters.dart';
import '../../data/repositories/run_repository.dart';
import '../../domain/tracking/run_tracker_controller.dart';
import '../widgets/campus_map_view.dart';
import '../widgets/gps_status_banner.dart';
import '../widgets/stat_card.dart';

/// Android 移动端核心跑步记录页面
class RunTrackingPage extends StatelessWidget {
  const RunTrackingPage({super.key});

  @override
  Widget build(BuildContext context) {
    final tracker = context.watch<RunTrackerController>();
    final repo = context.read<RunRepository>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('实时校园跑'),
        actions: [
          if (tracker.status == RunTrackingStatus.finished)
            TextButton.icon(
              onPressed: tracker.resetToIdle,
              icon: const Icon(Icons.refresh),
              label: const Text('新记录'),
            ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              GpsStatusBanner(
                status: tracker.status,
                errorMessage: tracker.errorMessage,
                filteredOutlierCount: tracker.filteredOutlierCount,
              ),
              const SizedBox(height: 12),
              Expanded(
                child: CampusMapView(
                  points: tracker.points,
                  highlightedPoint:
                      tracker.points.isNotEmpty ? tracker.points.last : null,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      label: '实时里程',
                      value: Formatters.distanceKm(tracker.distanceMeters),
                      icon: Icons.straighten,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: StatCard(
                      label: '运动时间',
                      value: Formatters.duration(tracker.movingDuration),
                      icon: Icons.timer_outlined,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      label: '平均配速',
                      value: Formatters.pace(tracker.currentPaceSecondsPerKm),
                      icon: Icons.speed,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: StatCard(
                      label: '累计爬升',
                      value: Formatters.elevation(tracker.elevationGainMeters),
                      icon: Icons.terrain,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _buildControlRow(context, tracker, repo),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildControlRow(
    BuildContext context,
    RunTrackerController tracker,
    RunRepository repo,
  ) {
    if (!tracker.isActive) {
      return SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          onPressed: tracker.startRun,
          icon: const Icon(Icons.play_arrow_rounded),
          label: const Text('开始真实 GPS 跑步记录'),
        ),
      );
    }

    return Row(
      children: [
        Expanded(
          child: tracker.status == RunTrackingStatus.paused
              ? FilledButton.icon(
                  onPressed: tracker.resumeRun,
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('恢复记录'),
                )
              : FilledButton.tonalIcon(
                  onPressed: tracker.pauseRun,
                  icon: const Icon(Icons.pause_rounded),
                  label: const Text('暂停'),
                ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              foregroundColor: Theme.of(context).colorScheme.onError,
            ),
            onPressed: () async {
              final session = await tracker.stopAndBuildSession();
              if (session != null) {
                await repo.saveSession(session);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        '已保存记录：${session.title}（${Formatters.distanceKm(session.distanceMeters)}）',
                      ),
                    ),
                  );
                }
              }
            },
            icon: const Icon(Icons.stop_rounded),
            label: const Text('结束并保存'),
          ),
        ),
      ],
    );
  }
}
