import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/repositories/run_repository.dart';

/// 移动端 GPX/KML 导入导出与 Windows 同步包导出页
class MobileRoutesPage extends StatelessWidget {
  const MobileRoutesPage({super.key});

  Future<void> _importTrack(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['gpx', 'kml'],
    );
    final path = result?.files.single.path;
    if (path == null || !context.mounted) return;
    try {
      final session =
          await context.read<RunRepository>().importGpxOrKmlFile(File(path));
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导入成功：${session.title}')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导入失败：$e')),
        );
      }
    }
  }

  Future<void> _exportSyncBundle(BuildContext context) async {
    final path = await FilePicker.platform.saveFile(
      dialogTitle: '导出同步包（传输至 Windows 11 桌面端分析）',
      fileName: 'campus_run_sync_${DateTime.now().millisecondsSinceEpoch}.json',
    );
    if (path == null || !context.mounted) return;
    await context.read<RunRepository>().exportSyncBundle(
          File(path),
          deviceTag: Platform.operatingSystem,
        );
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('同步包已导出：$path')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('文件导入与双端同步')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.file_upload_outlined),
              title: const Text('导入 GPX / KML 轨迹文件'),
              subtitle: const Text('解析标准 WGS84 轨迹并写入本地数据库'),
              onTap: () => _importTrack(context),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.sync_alt),
              title: const Text('导出离线同步包给 Windows 11'),
              subtitle: const Text('打包全部本地运动记录并附带 SHA-256 校验码'),
              onTap: () => _exportSyncBundle(context),
            ),
          ),
        ],
      ),
    );
  }
}
