import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/utils/formatters.dart';
import '../../data/models/run_session.dart';
import '../../data/repositories/run_repository.dart';

/// 移动端历史运动记录查询与导出页面
class HistoryListPage extends StatefulWidget {
  const HistoryListPage({super.key});

  @override
  State<HistoryListPage> createState() => _HistoryListPageState();
}

class _HistoryListPageState extends State<HistoryListPage> {
  List<RunSession> _sessions = const [];
  String _query = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    setState(() => _loading = true);
    final items = await context.read<RunRepository>().fetchSessions();
    if (!mounted) return;
    setState(() {
      _sessions = items;
      _loading = false;
    });
  }

  Future<void> _exportFile(RunSession session, String ext) async {
    final repo = context.read<RunRepository>();
    final path = await FilePicker.platform.saveFile(
      dialogTitle: '导出为 ${ext.toUpperCase()} 文件',
      fileName: '${session.id}.$ext',
    );
    if (path == null) return;
    final file = File(path);
    if (ext == 'gpx') {
      await repo.exportSessionToGpx(session, file);
    } else {
      await repo.exportSessionToKml(session, file);
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已导出至：$path')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _sessions
        .where((s) => s.title.toLowerCase().contains(_query.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('历史跑步记录'),
        actions: [
          IconButton(
            onPressed: _reload,
            icon: const Icon(Icons.refresh),
            tooltip: '刷新列表',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: '搜索记录标题...',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : filtered.isEmpty
                    ? const Center(child: Text('暂无历史跑步记录'))
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (context, index) {
                          final item = filtered[index];
                          return Card(
                            child: ListTile(
                              title: Text(
                                item.title,
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                '${Formatters.dateTime(item.startedAt)} · '
                                '${Formatters.distanceKm(item.distanceMeters)} · '
                                '${Formatters.duration(item.movingDuration)} · '
                                '配速 ${Formatters.pace(item.averagePaceSecondsPerKm)}',
                              ),
                              trailing: PopupMenuButton<String>(
                                onSelected: (action) async {
                                  if (action == 'gpx' || action == 'kml') {
                                    await _exportFile(item, action);
                                  } else if (action == 'delete') {
                                    await context
                                        .read<RunRepository>()
                                        .deleteSession(item.id);
                                    await _reload();
                                  }
                                },
                                itemBuilder: (_) => const [
                                  PopupMenuItem(value: 'gpx', child: Text('导出 GPX')),
                                  PopupMenuItem(value: 'kml', child: Text('导出 KML')),
                                  PopupMenuItem(value: 'delete', child: Text('删除记录')),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
