/// 应用统一异常体系，便于 UI 友好提示与日志记录
abstract class AppException implements Exception {
  const AppException(this.message, [this.cause]);

  final String message;
  final Object? cause;

  @override
  String toString() => cause == null ? message : '$message ($cause)';
}

class GpsServiceException extends AppException {
  const GpsServiceException(super.message, [super.cause]);
}

class StorageException extends AppException {
  const StorageException(super.message, [super.cause]);
}

class FileFormatException extends AppException {
  const FileFormatException(super.message, [super.cause]);
}

class SyncIntegrityException extends AppException {
  const SyncIntegrityException(super.message, [super.cause]);
}
