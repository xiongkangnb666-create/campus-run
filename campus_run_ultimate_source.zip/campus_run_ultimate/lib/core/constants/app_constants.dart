/// 应用全局常量与算法阈值配置
class AppConstants {
  AppConstants._();

  static const String appName = '校园跑终极版';
  static const String appVersion = '1.0.0';

  /// 默认地图初始中心点（WGS84，未定位时的安全回退坐标）
  static const double defaultLatitude = 39.9929;
  static const double defaultLongitude = 116.3059;
  static const double defaultZoom = 16.0;

  /// 轨迹采集与噪声过滤参数
  static const double maxAcceptableAccuracyMeters = 35.0;
  static const double minDistanceFilterMeters = 2.5;
  static const double maxHumanRunningSpeedMps = 12.5; // ~45 km/h 防止 GPS 漂移尖刺
  static const Duration gpsSignalTimeout = Duration(seconds: 15);
  static const Duration tickerInterval = Duration(seconds: 1);

  /// 离线瓦片/在线开源瓦片 URL（仅在联网时按需加载）
  static const String osmTileUrl =
      'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  static const String osmUserAgentPackage = 'com.campusrun.ultimate';

  /// 安全存储键名
  static const String keyDailyGoalKm = 'pref_daily_goal_km';
  static const String keyOfflineMapOnly = 'pref_offline_map_only';
  static const String keyAutoPauseEnabled = 'pref_auto_pause_enabled';
  static const String keySyncDeviceTag = 'pref_sync_device_tag';
}
