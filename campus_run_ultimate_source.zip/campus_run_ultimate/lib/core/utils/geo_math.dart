import 'dart:math' as math;

import '../../data/models/track_point.dart';

/// 轨迹地理数学工具（纯 Dart 离线计算）
class GeoMath {
  GeoMath._();

  static const double earthRadiusMeters = 6371000.0;

  /// Haversine 公式计算两点间 WGS84 球面距离（米）
  static double haversineDistanceMeters(
    double lat1,
    double lon1,
    double lat2,
    double lon2,
  ) {
    final dLat = _toRadians(lat2 - lat1);
    final dLon = _toRadians(lon2 - lon1);
    final rLat1 = _toRadians(lat1);
    final rLat2 = _toRadians(lat2);

    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(rLat1) *
            math.cos(rLat2) *
            math.sin(dLon / 2) *
            math.sin(dLon / 2);
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return earthRadiusMeters * c;
  }

  /// 计算轨迹总里程（米）
  static double totalDistanceMeters(List<TrackPoint> points) {
    if (points.length < 2) return 0.0;
    var sum = 0.0;
    for (var i = 1; i < points.length; i++) {
      sum += haversineDistanceMeters(
        points[i - 1].latitude,
        points[i - 1].longitude,
        points[i].latitude,
        points[i].longitude,
      );
    }
    return sum;
  }

  /// 计算累计爬升（米），带 1.5m 噪声死区过滤
  static double elevationGainMeters(
    List<TrackPoint> points, {
    double thresholdMeters = 1.5,
  }) {
    if (points.length < 2) return 0.0;
    var gain = 0.0;
    double? lastValidAlt;
    for (final p in points) {
      final alt = p.altitude;
      if (alt == null) continue;
      if (lastValidAlt == null) {
        lastValidAlt = alt;
        continue;
      }
      final diff = alt - lastValidAlt;
      if (diff >= thresholdMeters) {
        gain += diff;
        lastValidAlt = alt;
      } else if (diff <= -thresholdMeters) {
        lastValidAlt = alt;
      }
    }
    return gain;
  }

  /// 计算配速（秒/公里），里程过小时返回 null
  static double? paceSecondsPerKm(double distanceMeters, Duration movingTime) {
    if (distanceMeters < 10.0 || movingTime.inSeconds <= 0) return null;
    return movingTime.inSeconds / (distanceMeters / 1000.0);
  }

  /// 计算每公里分段配速（秒/公里列表）
  static List<double> kilometerSplitPaces(List<TrackPoint> points) {
    if (points.length < 2) return const [];
    final splits = <double>[];
    var segmentDistance = 0.0;
    var segmentStartTime = points.first.timestamp;

    for (var i = 1; i < points.length; i++) {
      final d = haversineDistanceMeters(
        points[i - 1].latitude,
        points[i - 1].longitude,
        points[i].latitude,
        points[i].longitude,
      );
      segmentDistance += d;
      if (segmentDistance >= 1000.0) {
        final elapsed =
            points[i].timestamp.difference(segmentStartTime).inSeconds;
        if (elapsed > 0) {
          splits.add(elapsed / (segmentDistance / 1000.0));
        }
        segmentDistance = 0.0;
        segmentStartTime = points[i].timestamp;
      }
    }
    return splits;
  }

  /// 判断新轨迹点是否为 GPS 漂移尖刺（超速或精度过差）
  static bool isOutlierPoint({
    required TrackPoint previous,
    required TrackPoint candidate,
    double maxSpeedMps = 12.5,
    double maxAccuracyMeters = 35.0,
  }) {
    if (candidate.accuracy != null && candidate.accuracy! > maxAccuracyMeters) {
      return true;
    }
    final dtSec =
        candidate.timestamp.difference(previous.timestamp).inMilliseconds /
            1000.0;
    if (dtSec <= 0) return true;
    final dist = haversineDistanceMeters(
      previous.latitude,
      previous.longitude,
      candidate.latitude,
      candidate.longitude,
    );
    return (dist / dtSec) > maxSpeedMps;
  }

  /// Douglas-Peucker 轨迹抽稀算法（用于长轨迹导出与回放性能优化）
  static List<TrackPoint> simplifyTrack(
    List<TrackPoint> points, {
    double toleranceMeters = 3.0,
  }) {
    if (points.length <= 2) return List<TrackPoint>.from(points);
    return _douglasPeucker(points, toleranceMeters);
  }

  static List<TrackPoint> _douglasPeucker(
    List<TrackPoint> points,
    double toleranceMeters,
  ) {
    var maxDist = 0.0;
    var index = 0;
    final end = points.length - 1;

    for (var i = 1; i < end; i++) {
      final d = _perpendicularDistanceMeters(
        points[i],
        points.first,
        points[end],
      );
      if (d > maxDist) {
        maxDist = d;
        index = i;
      }
    }

    if (maxDist > toleranceMeters) {
      final left = _douglasPeucker(points.sublist(0, index + 1), toleranceMeters);
      final right = _douglasPeucker(points.sublist(index), toleranceMeters);
      return [...left.sublist(0, left.length - 1), ...right];
    }
    return [points.first, points.last];
  }

  static double _perpendicularDistanceMeters(
    TrackPoint p,
    TrackPoint start,
    TrackPoint end,
  ) {
    final segLen = haversineDistanceMeters(
      start.latitude,
      start.longitude,
      end.latitude,
      end.longitude,
    );
    if (segLen < 1e-6) {
      return haversineDistanceMeters(
        p.latitude,
        p.longitude,
        start.latitude,
        start.longitude,
      );
    }
    // 局部平面投影近似（校园跑尺度 < 20km 误差可忽略）
    final cosLat = math.cos(_toRadians((start.latitude + end.latitude) / 2));
    final x0 = p.longitude * cosLat * 111320.0;
    final y0 = p.latitude * 110540.0;
    final x1 = start.longitude * cosLat * 111320.0;
    final y1 = start.latitude * 110540.0;
    final x2 = end.longitude * cosLat * 111320.0;
    final y2 = end.latitude * 110540.0;

    final num = ((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1).abs();
    final den = math.sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1));
    return den < 1e-6 ? 0.0 : num / den;
  }

  static double _toRadians(double deg) => deg * math.pi / 180.0;
}
