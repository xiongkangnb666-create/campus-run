import 'package:intl/intl.dart';

/// 中文运动数据格式化工具
class Formatters {
  Formatters._();

  static final DateFormat _dateTimeFmt = DateFormat('yyyy-MM-dd HH:mm');
  static final DateFormat _dateFmt = DateFormat('MM月dd日');

  static String distanceKm(double meters) {
    return '${(meters / 1000.0).toStringAsFixed(2)} 公里';
  }

  static String duration(Duration d) {
    final hours = d.inHours;
    final minutes = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:$minutes:$seconds';
    }
    return '$minutes:$seconds';
  }

  static String pace(double? secondsPerKm) {
    if (secondsPerKm == null ||
        secondsPerKm.isNaN ||
        secondsPerKm.isInfinite ||
        secondsPerKm <= 0 ||
        secondsPerKm > 3600) {
      return '--\'--"/公里';
    }
    final totalSec = secondsPerKm.round();
    final min = totalSec ~/ 60;
    final sec = (totalSec % 60).toString().padLeft(2, '0');
    return '$min\'$sec"/公里';
  }

  static String dateTime(DateTime dt) => _dateTimeFmt.format(dt.toLocal());

  static String shortDate(DateTime dt) => _dateFmt.format(dt.toLocal());

  static String elevation(double meters) => '${meters.toStringAsFixed(1)} 米';
}
