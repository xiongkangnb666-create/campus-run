import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/constants/app_constants.dart';
import 'core/theme/app_theme.dart';
import 'data/repositories/run_repository.dart';
import 'data/services/location_service.dart';
import 'domain/tracking/run_tracker_controller.dart';
import 'presentation/desktop/desktop_shell.dart';
import 'presentation/mobile/mobile_shell.dart';

/// Campus Run Ultimate 根应用（自动识别 Android 移动端与 Windows 11 桌面端）
class CampusRunApp extends StatelessWidget {
  const CampusRunApp({
    super.key,
    this.repository,
    this.locationService,
    this.forceDesktopMode,
  });

  final RunRepository? repository;
  final LocationService? locationService;
  final bool? forceDesktopMode;

  bool _isDesktopPlatform() {
    if (forceDesktopMode != null) return forceDesktopMode!;
    if (kIsWeb) return true;
    return Platform.isWindows || Platform.isLinux || Platform.isMacOS;
  }

  @override
  Widget build(BuildContext context) {
    final repo = repository ?? RunRepository();
    final locService = locationService ?? const GeolocatorLocationService();

    return MultiProvider(
      providers: [
        Provider<RunRepository>.value(value: repo),
        ChangeNotifierProvider<RunTrackerController>(
          create: (_) => RunTrackerController(locationService: locService),
        ),
      ],
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        darkTheme: AppTheme.dark(),
        themeMode: ThemeMode.system,
        locale: const Locale('zh', 'CN'),
        supportedLocales: const [Locale('zh', 'CN')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: _isDesktopPlatform() ? const DesktopShell() : const MobileShell(),
      ),
    );
  }
}
