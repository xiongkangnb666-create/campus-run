# GitHub 开源资源审查与依赖许可证清单

## 一、指定 5 个 GitHub 开源项目深度对比与合规复用结论

| GitHub 项目 | 许可证 | 架构与核心能力 | 维护状态 | 本项目复用决策与合规边界 |
| :--- | :--- | :--- | :--- | :--- |
| [flutter/flutter](https://github.com/flutter/flutter) | **BSD-3-Clause** | 基于 Skia/Impeller 渲染引擎与 Dart 编译器的跨平台 UI 框架，支持编译为 Android ARM 原生代码与 Windows x64 桌面应用 | 活跃维护（Google 官方） | **直接采用**：作为双端核心应用框架与 Material 3 UI 基座 |
| [fleaflet/flutter_map](https://github.com/fleaflet/flutter_map) | **BSD-3-Clause** | 纯 Flutter 实现、无商业厂商绑定的跨平台地图组件，支持瓦片图层、折线（`PolylineLayer`）、标记（`MarkerLayer`）与手势交互（[pub.dev 页面](https://pub.dev/packages/flutter_map)） | 活跃维护（已至 v8.x，兼容 v7/v8） | **直接采用**：用于 Android 实时轨迹地图、Windows 交互式路线编辑器与离线回放视图 |
| [Baseflow/flutter-geolocator](https://github.com/Baseflow/flutter-geolocator) | **MIT** | 跨平台真实 GPS 定位插件，支持 Android 前台服务保活通知、高精度导航模式与 Windows 定位接口（[pub.dev 许可证](https://pub.dev/packages/geolocator/versions/12.0.0/license)） | 活跃维护 | **直接采用**：仅调用系统真实 GPS 传感器采集轨迹 |
| [0xfnzero/gps-locator](https://github.com/0xfnzero/gps-locator) | **MIT**（附带地理区域数据为 ODbL 1.0） | Android 端开发者/QA 模拟定位工具，包含 Material 3 地图优先交互、GPX/KML 导入导出、WGS84 坐标路线管理与 AES-256-GCM 加密备份架构 | 近期活跃 | **仅参考合法交互与数据架构**：明确**不复用**任何 Android Mock Location / ADB 模拟定位代码；仅借鉴其 Material 3 地图优先布局与 GPX/KML + WGS84 路线管理设计思路 |
| [shortcuts/locationjoystick](https://github.com/shortcuts/locationjoystick) | **MIT** | Android 端基于开发者选项模拟定位的摇杆与路线回放应用，采用离线本地存储、无账号架构与 GPX 导入回放交互 | 近期活跃 | **仅参考合法离线交互模式**：明确**不复用**任何浮动摇杆、定位欺骗或模拟位置注入代码；仅借鉴其“完全离线、无强制账号、本地路线收藏与回放”的产品体验理念 |

---

## 二、本项目 `pubspec.yaml` 直接依赖与许可证清单

| 包名 | 版本约束 | 许可证 | 用途说明 | 来源链接 |
| :--- | :--- | :--- | :--- | :--- |
| `flutter` / `flutter_localizations` | SDK (`>=3.24.0`) | BSD-3-Clause | 跨平台 UI 框架与简体中文本地化 | [github.com/flutter/flutter](https://github.com/flutter/flutter) |
| `flutter_map` | `^7.0.2` | BSD-3-Clause | 跨平台地图显示、轨迹折线与路线编辑 | [pub.dev/packages/flutter_map](https://pub.dev/packages/flutter_map) |
| `latlong2` | `^0.9.1` | Apache-2.0 | WGS84 经纬度坐标对象模型 | [pub.dev/packages/latlong2/license](https://pub.dev/packages/latlong2/license) |
| `geolocator` | `^12.0.0` | MIT | 真实 GPS 定位流与 Android 前台定位通知 | [pub.dev/packages/geolocator/versions/12.0.0/license](https://pub.dev/packages/geolocator/versions/12.0.0/license) |
| `sqflite` | `^2.3.3+1` | BSD-2-Clause | Android 本地 SQLite 关系型数据库 | [pub.dev/packages/sqflite_common_ffi/license](https://pub.dev/packages/sqflite_common_ffi/license) |
| `sqflite_common_ffi` | `^2.3.3` | BSD-2-Clause | Windows 11 桌面端 SQLite FFI 驱动 | [pub.dev/packages/sqflite_common_ffi/license](https://pub.dev/packages/sqflite_common_ffi/license) |
| `flutter_secure_storage` | `^9.2.2` | BSD-3-Clause | Android Keystore / Windows Credential Manager 安全配置存储 | [pub.dev/packages/flutter_secure_storage](https://pub.dev/packages/flutter_secure_storage) |
| `file_picker` | `^8.1.2` | MIT | 跨平台原生文件选择器（GPX/KML/JSON 同步包） | [pub.dev/packages/file_picker/license](https://pub.dev/packages/file_picker/license) |
| `xml` | `^6.5.0` | MIT | GPX 1.1 与 KML 2.2 标准 XML 解析与生成 | [pub.dev/packages/xml/versions/3.7.0](https://pub.dev/packages/xml/versions/3.7.0) |
| `fl_chart` | `^0.69.0` | MIT | 桌面端里程柱状图与海拔剖面折线图 | [pub.dev/packages/fl_chart](https://pub.dev/packages/fl_chart) |
| `provider` | `^6.1.2` | MIT | 轻量级状态管理与依赖注入 | [pub.dev/packages/provider](https://pub.dev/packages/provider) |
| `path_provider` | `^2.1.4` | BSD-3-Clause | 跨平台应用本地数据目录定位 | [pub.dev/packages/path_provider](https://pub.dev/packages/path_provider) |
| `path` | `^1.9.0` | BSD-3-Clause | 跨平台路径拼接工具 | [pub.dev/packages/path](https://pub.dev/packages/path) |
| `intl` | `^0.19.0` | BSD-3-Clause | 中文日期与数字格式化 | [pub.dev/packages/intl](https://pub.dev/packages/intl) |
| `crypto` | `^3.0.5` | BSD-3-Clause | 离线同步包 SHA-256 完整性校验 | [pub.dev/packages/crypto](https://pub.dev/packages/crypto) |
| `flutter_lints`（dev） | `^5.0.0` | BSD-3-Clause | Dart/Flutter 静态代码规范检查 | [pub.dev/packages/flutter_lints](https://pub.dev/packages/flutter_lints) |

所有引入依赖均采用商业与开源友好的宽松许可证（MIT / BSD-2-Clause / BSD-3-Clause / Apache-2.0），与本项目的 MIT License 完全兼容，无 GPL 传染性风险。
