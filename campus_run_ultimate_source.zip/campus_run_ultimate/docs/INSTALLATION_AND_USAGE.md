# Campus Run Ultimate 安装与使用说明

## 一、Windows 11 编译与构建环境准备

由于本项目的最终二进制打包（Android `.apk` 与 Windows `.exe`）依赖本地 Flutter SDK、Android SDK 与 Visual Studio C++ 工具链，请在 **Windows 11（64 位）** 开发机上按以下步骤准备环境：

1. **安装 Flutter SDK（>= 3.24.0）**：从 [Flutter GitHub 仓库](https://github.com/flutter/flutter) 或官网下载 Windows 稳定版压缩包，解压至无中文/空格路径（例如 `C:\src\flutter`），并将 `C:\src\flutter\bin` 加入系统 `PATH`。
2. **安装 Android 构建工具链**：安装 Android Studio，在 SDK Manager 中勾选 `Android SDK Platform 35`、`Android SDK Build-Tools`、`Android SDK Command-line Tools`，随后运行 `flutter doctor --android-licenses` 接受许可协议。
3. **安装 Windows 11 桌面构建工具链**：安装 Visual Studio 2022（Community 即可），勾选 **“使用 C++ 的桌面开发”** 工作负载（含 MSVC v143、Windows 11 SDK 与 CMake）。
4. **验证环境**：
   ```powershell
   flutter doctor -v
   ```

## 二、一键构建 Android APK 与 Windows 11 运行包

解压源码包 `campus_run_ultimate_source.zip`，在项目根目录打开 PowerShell，执行内置脚本：

```powershell
.\scripts\build_all.ps1
```

或手动依次执行以下命令：

```powershell
flutter doctor
flutter pub get
flutter analyze
flutter test
flutter build apk --release
flutter build windows --release
```

### 构建产物位置

- **Android 安装包**：`build\app\outputs\flutter-apk\app-release.apk`
- **Windows 11 完整运行目录**：`build\windows\x64\runner\Release\`（运行其中的 `campus_run_ultimate.exe`，分发时请连同同目录下的 `*.dll` 与 `data\` 文件夹一并打包）。

### 可选：配置 Android 正式发布签名

在 `android/` 目录下新建 `key.properties`（该文件已被 `.gitignore` 忽略，**切勿提交至 Git**）：

```properties
storePassword=你的密钥库密码
keyPassword=你的密钥密码
keyAlias=你的别名
storeFile=../../my-release-key.jks
```

未提供 `key.properties` 时，Gradle 将自动回退至调试签名以便测试安装。

## 三、Android 端使用指南

1. **授予真实定位权限**：首次点击“开始真实 GPS 跑步记录”时，允许“精确位置”权限；若需息屏后台记录，请在系统设置中开启“始终允许”与通知权限（用于保持前台定位服务运行）。
2. **实时运动记录**：在户外空旷处等待状态栏由“正在搜索真实 GPS 卫星信号”切换为“GPS 信号稳定”，即可查看实时里程、用时、配速与累计爬升；支持随时暂停/恢复，系统会自动剔除精度 > 35m 或瞬时速度 > 12.5 m/s 的漂移点。
3. **导出与同步至电脑**：在“历史记录”页点击菜单导出单条 GPX/KML；或在“导入与同步”页点击“导出离线同步包给 Windows 11”，将生成的 `.json` 文件通过数据线或局域网传至电脑。

## 四、Windows 11 桌面端使用指南

1. **导入手机数据**：进入左侧“同步与导入导出”，点击“选择同步包”导入手机导出的 `.json` 文件（自动校验 SHA-256，防止文件损坏），或批量导入外部 `.gpx` / `.kml` 文件。
2. **运动统计仪表盘**：在“数据仪表盘”查看累计里程、运动次数、综合配速与近期里程趋势柱状图。
3. **校园路线编辑**：进入“路线编辑器”，点击地图依次添加途经点，实时查看规划里程，可保存至本地路线库或导出为标准 GPX / KML 文件。
4. **离线轨迹回放与分析**：进入“轨迹回放分析”，选择历史记录，可开启“纯离线模式”在无网环境下拖动时间轴或以 `1x/2x/5x/10x` 倍速回放，同时查看海拔变化剖面与每公里分段配速。
