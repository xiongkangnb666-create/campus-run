# Campus Run Ultimate（校园跑终极版）

基于 [Flutter](https://github.com/flutter/flutter) + Dart 构建的 **Android + Windows 11 双端校园跑合法辅助与轨迹分析软件**。采用 Material 3 中文界面、离线优先 SQLite 架构、标准 GPX 1.1 / KML 2.2 互操作以及带 SHA-256 完整性校验的双端离线同步机制。

> **合规声明**：本软件严格仅采集操作系统真实 GPS 传感器轨迹，**不包含任何模拟定位（Mock Location）、定位欺骗、第三方运动平台防作弊绕过或未经授权的成绩提交功能**。

## 核心功能一览

| 平台 | 核心模块 | 主要能力 |
| :--- | :--- | :--- |
| **Android 移动端** | 实时跑步采集 (`RunTrackingPage`) | 真实 GPS 轨迹采集、实时配速/里程/运动时长/累计爬升、GPS 信号丢失告警与自动恢复、暂停/恢复、异常漂移点过滤、Android 前台定位服务保活 |
| **Android 移动端** | 历史记录管理 (`HistoryListPage`) | 本地 SQLite 历史查询、标题搜索、单条记录导出 GPX / KML、删除管理 |
| **Android 移动端** | 导入与同步 (`MobileRoutesPage`) | 导入外部 GPX/KML 轨迹文件、一键打包导出含 SHA-256 校验码的离线同步包（`.json`）供 Windows 桌面端分析 |
| **Windows 11 桌面端** | 运动数据仪表盘 (`DesktopDashboardPage`) | 累计次数/总里程/总时长/综合配速 KPI 卡片、近期里程柱状图（`fl_chart`）、完整历史记录明细表 |
| **Windows 11 桌面端** | 交互式路线编辑器 (`RouteEditorPage`) | 基于 [flutter_map](https://github.com/fleaflet/flutter_map) 点击打点规划校园路线、实时里程测算、撤销/清空、保存路线库、导出 GPX/KML、支持离线视图切换 |
| **Windows 11 桌面端** | 离线轨迹回放与分析 (`TrackReplayPage`) | 纯离线时间轴拖动回放、`1x/2x/5x/10x` 倍速播放、移动标记、海拔剖面折线图、每公里分段配速分析 |
| **Windows 11 桌面端** | 数据同步与管理 (`DataSyncPage`) | 导入手机端离线同步包（自动执行 SHA-256 完整性校验）、批量导入 GPX/KML、全量本地数据库离线备份 |

## 项目目录结构

```text
campus_run_ultimate/
├── android/                  # Android 原生清单（前台定位权限）与 Gradle 配置
├── docs/                     # 安装使用说明、自动化测试报告、开源依赖与许可证清单
├── lib/
│   ├── core/                 # Material 3 主题、常量、异常体系、GeoMath 地理数学与格式化工具
│   ├── data/                 # TrackPoint/RunSession/CampusRoute 模型、SQLite、GPX/KML、安全存储、同步服务
│   ├── domain/tracking/      # RunTrackerController 跑步采集状态机（含 GPS 丢失恢复与滤波）
│   ├── presentation/
│   │   ├── mobile/           # Android 底部三标签界面
│   │   ├── desktop/          # Windows 11 侧边 NavigationRail 桌面界面
│   │   └── widgets/          # 跨平台地图组件、指标卡片与 GPS 状态横幅
│   ├── app.dart              # 双端自适应根应用
│   └── main.dart             # 程序入口
├── scripts/build_all.ps1     # Windows 11 一键检查、测试与双端打包脚本
├── test/                     # 单元与组件自动化测试套件（5 个测试文件）
├── analysis_options.yaml     # 严格 Dart 静态分析规则
├── pubspec.yaml              # 依赖清单
└── LICENSE                   # MIT License
```

## 快速构建与运行（Windows 11）

在已安装 Flutter SDK、Android SDK 与 Visual Studio 2022（C++ 桌面开发工作负载）的 Windows 11 环境下，于项目根目录执行：

```powershell
.\scripts\build_all.ps1
```

详细环境配置、签名密钥隔离与双端使用步骤请参阅 `docs/INSTALLATION_AND_USAGE.md`。

## 安全与隐私设计

- **防敏感信息入库**：`.gitignore` 已屏蔽 `key.properties`、`*.jks`、`*.keystore`、`.env`、`*.db` 与导出轨迹目录。
- **安全偏好存储**：使用 `flutter_secure_storage` 将设备标签与用户偏好存入系统密钥库（Android Keystore / Windows Credential Manager）。
- **离线优先**：所有跑步记录、路线规划、轨迹回放与统计分析均可在断网状态下本地运行（地图底图支持切换至“纯离线矢量视图模式”）。
